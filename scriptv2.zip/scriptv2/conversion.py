# -*- coding: utf-8 -*-
"""
Created on Wed Mar 29 09:32:28 2017

@author: Gabriel
"""

from astropy.time import Time


def convert_yyddss_yyddhhmm(date) :
    """Allow to convert an utc date in the format yy:dd:ssss to the format yy:dd:hh:mm
    
    parameters
    date -- date to convert (format yy:dd:sssss)
    
    return : utc date (format yy:dd:hh:mm)
    
    """
    form=date.split(':')
   
    if form[0]<='50' and form[0]>='0':
        year='20'+form[0]
    else:
        year='19'+form[0]
    day=form[1]
    h=int(float(form[2])/3600)
    m=int((float(form[2])/3600-h)*60)
    if m<10:
        m='0'+str(m)
    else:
        m=str(m)
    date_f=year+':'+day+':'+str(h)+':'+m
    return(date_f)

def convert_utc_mjd(date):
    """Allow to convert an utc date to a MJD date
    
    parameters
    date -- utc date to convert (format yy:dd:hh:mm)
    
    return : MDJ date  
    """
    dat_utc=convert_yyddss_yyddhhmm(date)
    date_result=Time(dat_utc)
    date_result.format='mjd'
    return date_result.value
    
if __name__ == '__main__':
    #test n°1 :
    date = "99:289:35204"
    conv = convert_utc_mjd(date)
    
    #test n°2 : 
    date2 = "11:070:20783"
    conv_2= convert_utc_mjd(date2)
    
    #test n°3
    date3 = "16:330:55384"
    conv_2= convert_utc_mjd(date3)