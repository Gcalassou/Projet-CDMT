# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 09:21:42 2017

@author: Gabriel
"""

"""
Script permettant de calculer les moindres carrées
"""
import numpy as np
#
class calcul_MC:
    def __init__(self, vecteur_deplacement_gps, vecteur_coord_ref_slr, vecteur_pos_slr, matrice_cov_gps, matrice_cov_slr, seuil):
        
        #vecteur des déplacements gps des stations GPS co-localisées
        self.vecteur_deplacement_gps= (vecteur_deplacement_gps[:,1]).reshape(vecteur_deplacement_gps.shape[0],1)
        self.code_slr_gps = vecteur_deplacement_gps[:,0]
        #vecteur des coordonnées de référence slr
        self.vecteur_coord_ref_slr = (vecteur_coord_ref_slr[:,1]).reshape(vecteur_coord_ref_slr.shape[0],1)
        self.code_slr_ref = vecteur_coord_ref_slr[:,0]
        #vecteur des positions des stations slr co-localisées
        self.vecteur_pos_slr = (vecteur_pos_slr[:,1]).reshape(vecteur_pos_slr.shape[0],1)
        self.code_slr_pos = vecteur_pos_slr[:,0]
        #matrice de covariance des stations GPS co-localisées
        self.matrice_cov_gps = matrice_cov_gps
        
        #matrice de covariance des stations slr co-localisées
        self.matrice_cov_slr = matrice_cov_slr
        
        self.tri_data = self.tri(self.vecteur_coord_ref_slr,self.vecteur_pos_slr, self.vecteur_deplacement_gps, self.matrice_cov_gps, self.matrice_cov_slr, self.code_slr_ref, self.code_slr_pos, self.code_slr_gps)
#        
#        self.vecteur_deplacement_gps = (self.tri_data[0])[:,1]
#        
#        self.matrice_cov_gps = self.tri_data[1]
#        
#        self.vecteur_pos_slr = self.tri_data[2]
#        
#        self.matrice_cov_slr = self.tri_data[3]
        
#        self.vecteur_coord_ref_slr = np.array((self.vecteur_coord_ref_slr)[:,1])
        #seuil entré par l'utilisateur pour le test des points slr faux
        self.seuil = float(seuil)
        
        
#        self.matriceA_init = self.A(self.vecteur_coord_ref_slr)
#        self.matriceP_init = self.P(self.matrice_cov_gps, self.matrice_cov_slr)
        
        #matrice A
        self.matriceA = self.A(self.vecteur_coord_ref_slr)
        #matrice B
        self.matriceB = self.B(self.vecteur_coord_ref_slr,self.vecteur_pos_slr, self.vecteur_deplacement_gps )
        #matrice P
        self.matrice_poids = self.P(self.matrice_cov_gps, self.matrice_cov_slr)
        #matrice normale "N"
        self.matriceN = self.N(self.matriceA, self.matrice_poids)
        #matrice K
        self.matriceK = self.K(self.matriceA,self.matrice_poids,self.matriceB )
        #resultat moindre carré matrice X
        self.matriceX = self.Xc(self.matriceN, self.matriceK)
        #matrice des résidus
        self.residus = self.V(self.matriceA, self.matriceB, self.matriceX)
        #facteur unitaire de variance
        self.sig = self.sigma(self.residus, self.matrice_poids, self.matriceB, self.matriceA)
        
        #variance des résidus
        self.matV = self.varV(self.sig, self.matrice_poids, self.matriceN, self.matriceA)
        #variance des solutions
        self.matXc = self.varXc(self.matriceN,self.sig, self.matriceA)
        
        self.pt_faux = self.test_point_faux()
        
        self.X_after_test = self.pt_faux[0]
        
        self.matriceA_after_test = self.pt_faux[1]
        
        self.matriceP_after_test = self.pt_faux[2]
        
        self.dX = self.deltaX(self.vecteur_pos_slr, self.vecteur_coord_ref_slr, self.matriceA, self.X_after_test)
        self.dCov = self.delta_cov(self.matriceA, self.matrice_poids, self.matriceN, self.vecteur_deplacement_gps, self.vecteur_coord_ref_slr, self.vecteur_pos_slr,\
                    self.matrice_cov_gps, self.matrice_cov_slr, self.matriceA_after_test, self.matriceP_after_test)
        
    def tri(self, xref, xslr, xgps, cov_gps, cov_slr, code_ref, code_slr, code_gps):
#        liste_delete = []
        
        if xref.shape[0] < xslr.shape[0] or xref.shape[0] < xgps.shape[0]:
            delete_gps, delete_slr = [], []
            for i in range(len(code_gps)):
                if code_gps[i] not in code_ref:
                    delete_gps +=[i]
            for i in range(len(code_slr)):
                if code_slr[i] not in code_ref:
                    delete_slr +=[i]
            self.vecteur_deplacement_gps = np.delete(xgps, delete_gps, 0)
            self.vecteur_pos_slr  = np.delete(xslr, delete_slr, 0)
            
            cov_xgps_temp = np.delete(cov_gps, delete_gps, 0)
            self.matrice_cov_gps = np.delete(cov_xgps_temp, delete_gps, 1)
            
            cov_xslr_temp = np.delete(cov_slr, delete_slr, 0)
            self.matrice_cov_slr = np.delete(cov_xslr_temp, delete_slr, 1)
#            for i in range(xslr.shape[0]):
        elif xslr.shape[0] < xref.shape[0] or xslr.shape[0] < xgps.shape[0]:
            delete_gps, delete_ref = [], []
            for i in range(len(code_gps)):
                if code_gps[i] not in code_slr:
                    delete_gps +=[i]
            for i in range(len(code_ref)):
                if code_ref[i] not in code_slr:
                    delete_ref +=[i]
            self.vecteur_deplacement_gps = np.delete(xgps, delete_gps, 0)
            self.vecteur_coord_ref_slr  = np.delete(xref, delete_ref, 0)
            
            cov_xgps_temp = np.delete(cov_gps, delete_gps, 0)
            self.matrice_cov_gps = np.delete(cov_xgps_temp, delete_gps, 1)
            
        elif xgps.shape[0] < xslr.shape[0] or xgps.shape[0] < xref.shape[0]:
            delete_ref, delete_slr = [], []
            for i in range(len(code_ref)):
                if code_ref[i] not in code_gps:
                    delete_ref +=[i]
            for i in range(len(code_slr)):
                if code_slr[i] not in code_gps:
                    delete_slr +=[i]
            self.vecteur_coord_ref_slr = np.delete(xref, delete_gps, 0)
            self.vecteur_pos_slr  = np.delete(xslr, delete_slr, 0)
            
            cov_xslr_temp = np.delete(cov_slr, delete_slr, 0)
            self.matrice_cov_slr = np.delete(cov_xslr_temp, delete_slr, 1)
            
            
            
#            
#            for j in range(xgps.shape[0]):
#                if xgps[j][0] not in xref[:, 0]:
#                    liste_delete += [j, j+1, j+2]
#            new_xgps = np.delete(xgps, liste_delete, 0)
#            new_xslr = np.delete(xslr, liste_delete, 0)
#            
#            cov_xgps_temp = np.delete(cov_gps, liste_delete, 0)
#            new_cov_xgps = np.delete(cov_xgps_temp, liste_delete, 1)
#            
#            cov_xslr_temp = np.delete(cov_slr, liste_delete, 0)
#            new_cov_xslr = np.delete(cov_xslr_temp, liste_delete, 1)
#        
#        return new_xgps, new_cov_xgps, new_xslr, new_cov_xslr
#                    presence_station = True
#            if presence_station == False:
                    
    def A(self, xref):
        """création de la matrice des paramètres "A"
        
        Entrée:
        -- xref : vecteur des coordonnées références gps
        Sortie:
        --modele : matrice des parametre dim = {3*nbr_stations, 7}
        """
#        xref =  self.vecteur_coord_ref_slr
        modele = np.zeros((xref.shape[0],7))
        c= np.pi/(180*3600)
        for i in range(modele.shape[0]):
            if i%3== 0:
                modele[i]= [1]+[0]*2+[xref[i]*1e-6]+[0]+[c*xref[i+2]]+[-c*xref[1+i]]
            if i%3 ==1:
                modele[i] = [0]+[1]+[0]+[xref[i]*1e-6]+[-c*xref[i+1]]+[0]+[c*xref[i-1]]
            if i%3 == 2 :
                modele[i] = [0]+[0]+[1]+[xref[i]*1e-6]+[c*xref[i-1]]+[-c*xref[i-2]]+[0]
        return modele
    
    def B(self, xref, xslr, xgps):
        """Création de la matrice des observations
        
        Entrée:
        -- xref : vecteur des coordonnées de référence slr
        -- xslr : vecteur des positions des stations slr co-localisées
        -- xgps : matrice de covariance des stations GPS co-localisées
        
        Sortie :
        -- obs : matrice des observations "B"; dimB = {3*nbr_stations, 1}
        """
        obs = np.zeros((xslr.shape[0], 1))
        for i in range(xslr.shape[0]):
            obs[i]=float(xslr[i][0])-float(xref[i][0])-float(xgps[i][0])
        return obs
    
    
    def P(self, mat_cov_gps, mat_cov_slr):
        """Création de la matrice de poids
        
        Entrée:
        -- mat_cov_gps : 
        -- mat_cov_slr : 
        
        Sortie:
        -- poids : 
        """
#        mat_cov_gps = self.matrice_cov_gps 
#        mat_cov_slr = self.matrice_cov_slr
        mat_temp = mat_cov_gps + mat_cov_slr
        poids = np.linalg.inv(mat_temp)
        return poids
        
    def N(self, A_test, P_test):
        """Création de la matrice normale
        
        Entrée:
        -- A_test : matrice A
        -- P_test : matrice P
        
        Sortie:
        -- mat : matrice normale; dimN = {7,7}
        """
        mat = np.dot(A_test.T, np.dot(P_test, A_test))

        return mat
    
    
        
    def K(self,  A_test, P_test, B_test):
        """Création de la matrice K
        
        Entrée:
        -- A_test : matrice A
        -- P_test : matrice P
        -- B_test : matrice B
        
        Sortie 
        -- mat : matrice K; dimK = {7,1}
        """
        mat = np.dot(A_test.T, np.dot(P_test, B_test))
        return mat
    
    def Xc(self, N_test, K_test):
        """Calcul de la solution des moindres carrées
        
        Entrée:
        -- N_test : matrice normale
        -- K_test : matrice K
        
        Sortie:
        -- mat : vecteur solution des moindre carrée
        """
        mat = np.dot(np.linalg.inv(N_test), K_test)
        return mat
        
    def V(self, A_test, B_test, X_test):
        """Création du vecteur des résidus
        
        Entrée:
        -- A_test : matrice A
        -- B_test : matrice B
        -- X_test : vecteur solution des moindre carrée
        
        Sortie:
        -- V_test : vecteur des résidus; dimV = {3*nbr_station, 1}
        """
        mat = B_test-np.dot(A_test, X_test)
        return mat
    
    def sigma(self, V_test, P_test, B_test, A_test):
        """Calcul du facteur unitaire de variance
        
        Entrée:
        -- V_test : vecteur des résidus
        -- P_test : matrice P
        -- B_test : matrice B
        -- A_test : matrice A
        
        Sortie:
        -- sig : facteur unitaire de variance
        """
        nbr_obs = B_test.shape[0]
        parametre = A_test.shape[1]
        sig=(np.dot(V_test.T,np.dot(P_test,V_test)))/(nbr_obs-parametre)
        return sig
    
    def varXc(self, N_test, sig2, A_test):
        """Calcul de la variance des solutions
        
        Entrée:
        -- N_test : matrice normale
        -- sig2 : facteur unitaire de variance
        -- A_test : matrice A
        
        Sortie:
        -- result : variance des solutions; dimvarXc = {3*nbr_stations, 3*nbr_stations}
        """
        return sig2*np.linalg.inv(N_test)
        
    def varV(self, sig, P_test, N_test, A_test):
        sig = self.sig
        poids = np.linalg.inv(P_test)
        n_inv= np.linalg.inv(N_test)
        a=A_test
        result= sig*(poids-np.dot(a,np.dot(n_inv,np.transpose(a))))
        return result
        
    def test_point_faux(self):
        """Test des points faux des moindres carrées
        
        Sortie :
        --   : solution des moindre carrées ré-estimé
        """
        xgps = self.vecteur_deplacement_gps 
        xref = self.vecteur_coord_ref_slr 
        xslr = self.vecteur_pos_slr 
        mat_cov_gps = self.matrice_cov_gps 
        mat_cov_slr = self.matrice_cov_slr 
        
        V1 = self.residus 
        mV = self.matV 
        diag_vv = np.diag(mV)
        X_result= self.matriceX
        A_result = self.matriceA
        P_result = self.matrice_poids

        val_test = -1
        indice_test = 0
        for i in range(V1.shape[0]):
            vi = abs(V1[i][0]/diag_vv[i])
            if vi > val_test:
                val_test = vi
                indice_test = [i//3, (i//3)+1, (i//3)+2]
        compteur = 0
        while val_test > self.seuil:
            print('on itère')
            xref = np.delete(xref, indice_test, 0)
            xgps = np.delete(xgps, indice_test, 0)
            xslr = np.delete(xslr , indice_test, 0)
            
            matrice_cov_gps_temp = np.delete(mat_cov_gps, indice_test, 0)
            mat_cov_gps = np.delete(matrice_cov_gps_temp, indice_test, 1)
            matrice_cov_slr_temp = np.delete(mat_cov_slr, indice_test, 0)
            mat_cov_slr = np.delete(matrice_cov_slr_temp, indice_test, 1)
            A1 = self.A(xref)
            B1 = self.B(xref, xslr, xgps)
            P1 = self.P(mat_cov_gps, mat_cov_slr)
            N1 = self.N(A1, P1)
            K1 = self.K(A1, P1, B1)
            X1 = self.Xc(N1, K1)
            V1 = self.V(A1, B1, X1)
            sigma1 = self.sigma(V1, P1, B1, A1)
            mV = self.varV(sigma1, P1, N1, A1)
            compteur += 1
            diag_vv = np.diag(mV)
            val_test = -1
            indice_test = 0
            for i in range(V1.shape[0]):
                vi = abs(V1[i][0]/diag_vv[i])
                if vi > val_test:
                    val_test = vi
                    indice_test = [i//3, (i//3)+1, (i//3)+2]
            X_result = X1
            A_result = A1
            P_result = P1
#            liste_vi += [vi]
#        val_test = np.max(liste_vi)
#        print(self.matriceA_init.shape, self.matriceP_init.shape)
        return X_result, A_result, P_result
        
        
    def deltaX(self, xslr, xref, A_test, X_modif):
#        facteur = np.dot(A_test, np.dot(np.linalg.inv(N_test),np.dot(np.transpose(A_test), P_test)))
#        I = np.eye(A_test.shape[0])
#        temp1 = np.dot((I - facteur), xslr)
#        temp2 = np.dot(facteur, xgps )
#        temp3 = np.dot((I - facteur), xref)
#        resultat = temp1 + temp2 + temp3
#        print( xslr.shape, xref.shape, A_test.shape, X_modif.shape)
#        print(np.dot(A_test, X_modif))
        dx = xslr - xref - np.dot(A_test, X_modif)
        print(dx.shape)
        return dx
        
    def delta_cov(self, A_test, P_test, N_test, xgps, xref, xslr, cov_gps, cov_slr, A_modif, P_modif):
        N_modif = self.N(A_modif, P_modif)
        facteur = np.dot(A_test, np.dot(np.linalg.inv(N_modif),np.dot(np.transpose(A_modif), P_test)))
        I = np.eye(A_test.shape[0])
        C = I- facteur
        D = facteur
        temp1 = np.dot(C, np.dot(cov_slr, np.transpose(C)))
        temp2 = np.dot(D, np.dot(cov_gps, np.transpose(D)))
        resultat = temp1 + temp2
        return resultat
            
        

if __name__ == "__main__":
#    mon_fichier = "path"
    xslr = 2*np.ones((12,1))
    xref = 7*np.ones((12,1))
    xgps = 3*np.ones((12,1))
    mat_cov_gps= np.random.rand(12,12)
    mat_cov_slr = np.random.rand(12,12)
    seuil = 5
#    mat_cov_gps= np.diag(np.random.rand(12))
#    mat_cov_slr = np.diag(np.random.rand(12))
    mc = calcul_MC(xgps,xref,xslr, mat_cov_gps, mat_cov_slr, seuil)
    #création de la matrice A
    a = mc.matriceA
    
    #creation de la matrice des observations B
    b = mc.matriceB
    
    #création de la matrice de poids
    p= mc.matrice_poids
    
    #création de la matrice normale N et de son inverse K
    n = mc.matriceN
    k = mc.matriceK
    
    #création de la matrice solution
    x_chapeau = mc.matriceX
    
    #création de la matrice des résidus
    v_chapeau = mc.residus
    
    #création de facteur unitaire de variance
    sig = mc.sig
    
    #création de la variance de x
    var_x = mc.matXc
    
    #création de la variance des résidus
    var_res = mc.matV
    
    #test de points faux slr
    test_mc = mc.test_point_faux()
    
    #calcul du delta x
    deltaxxx = mc.dX
    
    