# -*- coding: utf-8 -*-
"""
Created on Wed Mar  8 14:46:21 2017

@author: dpts
"""


"""
ce script fonctionne
"""

import ftplib as ftp

class Ftp(object):
    
    def __init__(self,address,listDir):
        """
        address : adresse du ftp, chaine de carac, forme 'cddis.nasa.gov'
        listDir : liste contenant les répertoires successifs dans le bon ordre
        """
        self.address = address
        self.listDir = listDir
        
        

    def connexion(self):
        """
        permet de se connecter au ftp
        """        
        
        connex = ftp.FTP(self.address)
        connex.login()
        
        
    def connexion_changeDir_download(self,ftpfile):
        """
        connexion au ftp, changement de répertoire puis téléchargement du fichier ftpfile
        """
        
        connec = ftp.FTP(self.address)
        connec.login()
        n = len(self.listDir)
        for i in range(0,n):
            connec.cwd(self.listDir[i])
#        print(connec.dir())
        connec.retrbinary('RETR '+ftpfile, open(ftpfile,'wb').write)  #transfert de fichiers en binaire
        #connec.retrlines('RETR '+ftpfile, open(ftpfile,'wb').write) #transfert de fichiers en ascii mode
        
        
        
#essai pour récupérer un fichier       
#test = Ftp('itrf.ign.fr',['incoming'])
##
#test.connexion_changeDir_download('codomes_gps.snx')

test = Ftp('ftp2.ign.fr',['simulation','annuel_avec_bruit'])
test.connexion_changeDir_download('SNXOUT1001.SNX')
