# -*- coding: utf-8 -*-
"""
Created on Sat Apr  8 11:27:34 2017

@author: Gabriel
"""
import Ftp as ftp
import os


class GPS_ref:
    def __init__(self):
        self.path = 'IGS14.ssc'
    
    def presence_fichier(self):
        if os.path.exists(self.path) == False:
            mon_ftp=ftp.Ftp('igs-rf.ensg.eu',['pub', 'IGS14'],'','')
            mon_ftp.connexion_changeDir_download(self.path,'')
            
if __name__ == '__main__':
    test = GPS_ref()
    test.presence_fichier()