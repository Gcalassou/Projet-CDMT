# -*- coding: utf-8 -*-
"""
Created on Sun Apr 30 10:27:43 2017

@author: Gabriel
"""
import scipt_test2 as sc2

class test1():
    def __init__(self):
        self.var1 = self.lecture()[0]
        self.var2 = self.lecture()[1]
        self.var3 = self.lecture()[2]
    def change(self):
        self.var1 = 10
        self.var2 = 12
        self.var3 = 14
    
    def lecture(self):
        print('tata')
        fichier = open('tt.txt', 'r')
        lignes = fichier.readline()
        lignes = lignes.split()
        liste = []
        for ligne in lignes :
#            ligne = ligne.split()
            liste += [ligne]
        fichier.close()
        return liste
    def tttt(self):
        return sc2.var1, sc2.var2
    




if __name__ == '__main__':
    t = test1()
    t.lecture()
    print(t.var1, t.var2, t.var3)