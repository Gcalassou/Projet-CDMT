# -*- coding: utf-8 -*-
"""
Created on Sun Apr 30 11:14:40 2017

@author: Gabriel
"""

class options:
    def __init__(self, path_fichier_option):
        self.path_fichier_option = path_fichier_option
        
        self.information_fichier = self.lecture_options()
        self.dossier_gps  = self.information_fichier[0]#'simulations_test\\GPS'
        
        #fichier_slr = 'simulations_test\\annuel_sans_bruit\\SNXOUT1030.SNX'
        self.fichier_slr = self.information_fichier[1]#'simulations_test\\annuel_avec_bruit\\SNXOUT1030.SNX'
        
        self.fichier_ref_gps = self.information_fichier[2]#simulations_test\\IGS14.ssc'
        
        self.fichier_ref_slr = self.information_fichier[3]#'simulations_test\\SLRF2008_150928_2015.09.28.snx'
        
        self.psd_slr = self.information_fichier[4]
        
        self.soln_slr = self.information_fichier[5]
        
        self.fichier_domes = self.information_fichier[6]#'simulations_test\\codomes_coord.snx'
        
        self.fichier_preference_gps = self.information_fichier[7]
        
        self.seuil_gps = self.information_fichier[8]
        
        self.seuil_slr = self.information_fichier[9]
        
        self.seuil_test_2 = 0

    def lecture_options(self):
        print('test')
        fichier = open(self.path_fichier_option, 'r')
        lignes = fichier.readlines()
        for ligne in lignes:
            ligne = ligne.split()
            if ligne[0]== 'chemin_dossier_gps': 
                try:
                    dossier_gps = ligne[1]
                except:
                    print("Le chemin du dossier du fichier gps n'a pas été trouvé")
            
            elif ligne[0]== 'chemin_fichier_snx': 
                try:
                    fichier_slr = ligne[1]
                except:
                    print("Le fichier slr n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_coordonees_reference_gps':
                try:
                    fichier_ref_gps = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_coordonees_reference_slr':
                try:
                    fichier_ref_slr = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_SOLN':
                try:
                    soln_slr = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_psd':
                try:
                    psd_slr = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_domes':
                try:
                    fichier_domes = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_preference_gps':
                try:
                    fichier_preference_gps = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'seuil_gps':
                try:
                    seuil_gps = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'seuil_slr':
                try:
                    seuil_slr = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
        fichier.close()
        
        return dossier_gps, fichier_slr, fichier_ref_gps, fichier_ref_slr, psd_slr, soln_slr, fichier_domes, fichier_preference_gps, seuil_gps, seuil_slr
        