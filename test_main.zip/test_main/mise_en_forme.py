# -*- coding: utf-8 -*-
"""
Created on Sun Apr 30 11:07:58 2017

@author: Gabriel
"""
#import options as opt
import fichier_ref as ref
#import station_co_loc 
import numpy as np 

#scl = station_co_loc.station_co_loc()
"""
Script permettant de construire dans un premier temps le vecteur des 
déplacements GPS et de la matrice de variance-covariance des déplacements
GPS. Puis dans un deuxieme temps de tester les points GPS retenus pour 
éliminer les points "faux" (points ne respectant pas le seuil fixé par l'utilisateur).

Entrée:
-- slc.remplissage() : matrice contenant les différentes informations des stations GPS
                       co-localisées. Chaque lignes contient les informations suivantes:
                        [code_slr, code_GPS {associé}, jour de mesure, de, dn, dh, dsigma_x, d_sigma_n, d_sigma_h]
                        l'ensemble des données est en format {string}

Sortie:
-- mat_xyz() : vecteur des déplacements GPS des stations co-localisées

-- mat_cov() : matrice des variances-covariances des déplacements GPS des stations 
               co-localisées
"""


class organisation_data_gps:
    def __init__(self, information_station_gps_coloc, fichier_coordonnées_référence_gps):
        self.information_station_gps_coloc = information_station_gps_coloc
        
        self.fichier_coordonnées_référence_gps = fichier_coordonnées_référence_gps
        
        self.matrice_coord_ref_gps = self.coord_ref_gps()[0]
        
        self.code_slr_retenu = self.coord_ref_gps()[1]
        
        
        self.rotation = self.R()
        
        self.vecteur_deplacement = self.mat_xyz()
        
        self.covariance_cartesienne = self.covariance_xyz()
        
        self.matrice_covariance_gps = self.mat_cov()
        
        
   
        
        
    def coord_ref_gps(self):
        """Fonction permettant les coordonées GPS approchées en fonction d'une station laser
        parametres
        -- coord : liste des coordonnées extraite du fichier snx voulu
        
        return 
        -- resultat_coord_ref : matrice contenant pour chaque station gps co-localisée
                                ses coordonnées de références en coordonnées géographiques
        """
        #chemin du fichier des coordonnées de référence des stations GPS
        path = self.fichier_coordonnées_référence_gps
        
        #initialisation de la matrice de sortie
        resultat_coord_ref = np.array([[]])
        
        #matrice contenant les données des coordonnées de références
        coord_ref = ref.lecture_fichier_ref(path)
        
        #liste des stations GPS co-localisées
        liste_gps_temp = self.information_station_gps_coloc[:, 1]
        
        #liste des stations slr associées
        liste_slr_temp = self.information_station_gps_coloc[:, 0]
        
        liste_gps = []
        liste_slr = []
        
        #on parcours la liste des stations GPS pour obtenir leurs coordonnées
        #de références
        for i in range(liste_gps_temp.shape[0]):
            if liste_gps == [] or liste_gps_temp[i] != liste_gps[-1]:
                
                
                liste_gps +=[liste_gps_temp[i]]
                liste_slr +=[int(liste_slr_temp[i])]
        #on stocke les coordonnées de références
        liste_gps = np.array(liste_gps)
        
        liste_slr = np.array(liste_slr)
        
        #on parcours la liste des coordonnées de reférence pour convertir celles-ci 
        for k in range(len(liste_gps)):
            for i in range(len(coord_ref)):
                if coord_ref[i][0] ==liste_gps[k]:
                    
                    # passage de la longitude de degres/minutes/secondes au degres decimaux
                    longitude = float(coord_ref[i][1][2])/3600 + float(coord_ref[i][1][1])/60 + float(coord_ref[i][1][0])
                    
                    # passage de la latitude de degres/minutes/secondes au degres decimaux
                    latitude= float(coord_ref[i][2][2])/3600 + float(coord_ref[i][2][1])/60 + float(coord_ref[i][2][0])
                    
                    data_gps = np.array([[coord_ref[i][0], longitude, latitude, coord_ref[i][3]]])
                    if resultat_coord_ref.shape == (1,0):
                        resultat_coord_ref = data_gps
                    else:
                        resultat_coord_ref = np.concatenate((resultat_coord_ref, data_gps), axis = 0)
                    break
        return resultat_coord_ref, liste_slr
        
    def R(self):
        """
        Creer la matrice de rotation R
        Arguments:
            lbd : longitude du GPS étudiée en degrès décimaux
            phi : latitude du GPS étudiée en degrès décimaux
            
        sortie 
        -- r : matrice de rotation R en fonction des coordonnées de référence d'une station GPS
        -- mat_R : liste de listes où les sous-listes contiennent le code des stations GPS
                   associées à leur matrice de rotation R
        """
        print('test')
        #on récupère la matrice contenant le code des stations GPS et leurs coordonnées 
        #de références
        mat_coord = self.matrice_coord_ref_gps
        mat_R = []
        
        #on calcule les matrices de rotation pour chacune des stations GPS co-localisées
        for i in range(mat_coord.shape[0]):
            
            lbd= (float(mat_coord[i][1])*np.pi)/180  #longitude en radian
            phi= (float(mat_coord[i][2])*np.pi)/180  #latitude en radian
            
            #calcule des matrices de rotations
            r=np.array([[-np.sin(lbd), np.cos(lbd),0],
                     [np.sin(phi)*np.cos(lbd), -np.sin(lbd)*np.sin(phi),np.cos(phi)],
                      [np.cos(phi)*np.cos(lbd), np.cos(phi)*np.sin(lbd),np.sin(phi)]])
            mat_R +=[[mat_coord[i][0], r]]
            
        return mat_R
        
    def mat_xyz(self):
        """
        Creer la matrice la matrice des déplacements en coordonnées cartesiennes
        de la station GPS étudiées sous le format:
        [[dx_1,dy_1,dz_1]
         [dx_2,dy_2,dz_2]
         ...,
         [dx_n,dy_n,dz_n]]
        """
        mat1=self.information_station_gps_coloc
        
        #liste des matrices de rotation
        R=self.rotation
        
        #matrice de sortie
        ma = np.array([[]])
        
        #on calcule les déplacements en coordonnées cartésiennes pour chaque station GPS
        #co-localisées
        for i in range(mat1.shape[0]):
            for j in range(len(R)):
                if mat1[i][1]==R[j][0]:
                    mat_temp = np.array([[float(mat1[i][4])],[float(mat1[i][5])], [float(mat1[i][6])]])

                    temp =np.dot(R[j][1],mat_temp).reshape(1,3)
                    if ma.shape == (1,0):
                        ma = np.array([[mat1[i][1], temp[0][0], temp[0][1], temp[0][2]]])
                        
                    else:
                        temp2 = np.array([[mat1[i][1], temp[0][0], temp[0][1], temp[0][2]]])
                        ma = np.concatenate((ma, temp2))
                    break
                    
        return ma
        
    def covariance_xyz(self):
        """Permet de construire la liste des différentes diagonales composants R
        
        Entrée:
        -- ma_code : code des stations GPS co-localisées
        -- ma_sigma : matrice contenant les d_sigma des stations GPS
        Sortie:
            cov : liste des termes composant les diagonales de la matrice de covariance
                  permettant de construire par la suite la matrice des d_sigma
                  dim(R)=(3,3) --> 5 diadonales
        """
        ma_code = self.information_station_gps_coloc[:,1]
        ma_sigma = self.information_station_gps_coloc[:,-3:]
        R= self.rotation
        
        #liste de listes dont les sous-listes contiendront les diagonales de la matrice des
        #d_sigma en coordonnées cartesiennes
        cov = [[],[],[],[],[]]
        
        dec_cov=[]
        
        #calcule de la matrice des covariances de chaque station GPS co-localisées
        for i in range(ma_sigma.shape[0]):
            sigma = np.diag([float(ma_sigma[i][0]), float(ma_sigma[i][1]), float(ma_sigma[i][2])])
            for j in range(len(R)):
                if ma_code[i] == R[j][0]:

                    cov1= np.dot(R[j][1], np.dot(sigma.T, R[j][1].T))
                    break
            #on récupère les différentes diagonales des matrices de covariances 
            for k in range(-2,3):     
                dec_cov= np.diag(cov1,k)

                #on stocke les diagonales dans la liste de listes
                for elt in dec_cov:
                        cov[2+k]+=[elt]
                if i < ma_sigma.shape[0]-1:
                    cov[2+k]+=abs(k)*[0]

        return cov
        
    def mat_cov(self):
        """Permet de construire la matrice des d_sigma en coordonnées cartesiennes
        Entrée:
        -- 
        
        Sortie:
        --result : matrice des matrices de variance-covariance des stations GPS
            [[R1,0 ,...,0   ,0 ]
             [0 ,R2,...,0   ,0 ]
             ...,
             [0 ,0 ,...,Rn-1,0 ]
             [0 ,0 ,...,0   ,Rn]]
        
        """
        #liste de listes dont les sous-listes contenant les diagonales de la matrice des
        #d_sigma en coordonnées cartesiennes
        cov= self.covariance_cartesienne

        result= np.zeros((len(cov[2])))
        
        #on stocke les matrices de variance-covariance dans la matrice de sortie
        for k in range(-2,3):
            test= np.diag(cov[k+2],k)

            result=result+test

        return result
    
###############################################################################    
    """Partie nettoyage des points faux
    
    Cette partie se décompose en quatre parties:
    -- la conversion de la durée de mesure en fraction de jours et jours julien modifiée
    -- récupérer les dx, dy, dz, dsigma_x, dsigma_y, dsigma_z
    -- calculer la moyenne pondérée sur chaque composantes
    -- effectuer des tests pour identifier les points faux ou non
    
    """
    def moy_ponderee(self):
        """Fonction permettant de calculer la moyenne pondérée
        
        """
        mat = self.information_station_gps_coloc
        station_temp = ''
        n = 0
        i = 0
        p = np.array([[]])
        resultat = np.array([[]])
        while i < mat.shape[0]:
            if station_temp == '':
                station_temp = mat[i][0]
            if mat[i][0] == station_temp:
                n += 1
                p_temp = np.array([[float(mat[i][2])/(float(mat[i][7]))**2,
                                    float(mat[i][2])/(float(mat[i][8]))**2, 
                                    float(mat[i][2])/(float(mat[i][9]))**2 ]])
                coord_temp = np.array([[float(mat[i][4]), float(mat[i][5]), float(mat[i][6])]])
                if p.shape == (1,0):      
                    p = p_temp
                    coord = coord_temp
                else:
                    p = np.concatenate((p, p_temp))
                    coord = np.concatenate((coord, coord_temp))
#                print(coord, p)
            if mat[i][0] != station_temp or i== mat.shape[0]-1:
                #on calcule dans cette partie la somme des p[i]*xyz[i]
                #--sum_coord : liste contenant la somme des p[i]*xyz[i] pour chaque composante
                #              dim(sum_coord) = (1,3)
                sum_coord = []
                for j in range(coord.shape[1]):
                    sum_temp_coord = 0
                    for k in range(coord.shape[0]):
                        sum_temp_coord += coord[k][j]*p[k][j]
                    sum_coord += [sum_temp_coord]
                    
                coord_moy = np.array([[(1/np.sum(p[:,0]))*(sum_coord[0]), 
                                       (1/np.sum(p[:,1]))*(sum_coord[1]), 
                                        (1/np.sum(p[:,2]))*(sum_coord[2])]])
                                        
#                print(mat[i-1][0], (1/np.sum(p[:,1])),sum_coord[1], (1/np.sum(p[:,1]))*(sum_coord[1]))
#                sum_1 = 0
                sum_2 = []
                for j in range(coord.shape[1]):
                    sum_1 = 0
                    for k in range(coord.shape[0]):
                        sum_1 += ((coord[k][j] - coord_moy[0][j])**2)*p[k][j]
                    sum_2 += [sum_1]
#                print(sum_2)
                if n > 1:
#                    print((1/np.sum(p[:,0]))*(1/(n-1))*sum_2[0],1/(n-1))
                    sigma = np.array([[mat[i-1][0], 
                                       np.sqrt((1/np.sum(p[:,0]))*(1/(n-1))*sum_2[0]),
                                       np.sqrt((1/np.sum(p[:,1]))*(1/(n-1))*sum_2[1]),
                                        np.sqrt((1/np.sum(p[:,2]))*(1/(n-1))*sum_2[2])]])
                else:
                    sigma = np.array([[mat[i-1][0], 
                                       mat[i-1][7],
                                       mat[i-1][8],
                                       mat[i-1][9]
                    ]])
                if resultat.shape ==(1,0):
                    resultat = sigma
                else:
                    resultat = np.concatenate((resultat, sigma))
                station_temp = mat[i][0]
                p = np.array([[]])
                n = 0
                if i <mat.shape[0]-1:
                    i -= 1
            
            i += 1
        
        return resultat
    
#    def test_point(self):
#        mat = self.station_coloc
#        moy = self.moy_ponderee()
#        for i in range(mat.shape[0]):
#            while mat[i][0] != moy[j][0]:
                
                
#    def test_point_faux_gps(self):


            
if __name__ == '__main__':
    org = organisation_data_gps()
#    gps_data_org = org.station_coloc
#    gps_coord_ref = org.coord_ref_gps()  
#    gps_matrice_R = org.R()
    gps_vecteur_deplacement = org.mat_xyz()
    gps_covariance_deplacement = org.covariance_xyz()  
#    gps_matrice_covariance = org.mat_cov()
#    gps_moyenne = org.moy_ponderee()
    