# -*- coding: utf-8 -*-
"""
Created on Mon May  8 17:12:22 2017

@author: Gabriel
"""

import options as opt
import station_co_loc 
import lecture_fichier_snx
#from options import options('simulations_test\\fichier_options.txt')
import mise_en_forme 



o = opt.options('simulations_test\\fichier_options.txt')

print(o.dossier_gps)
print(o.fichier_domes)

lfs = lecture_fichier_snx.Laser(o.fichier_slr)

slc = station_co_loc.station_co_loc(o.dossier_gps, lfs.bloc_epoch)

test_station_co_loc = slc.stations_GPS_coloc

org  = mise_en_forme.organisation_data_gps(slc.stations_GPS_coloc, o.fichier_ref_gps)

test_vecteur_deplacement = org.vecteur_deplacement
#org = mef.organisation_data_gps()
#org.mat_cov()
#org.mat_xyz()
