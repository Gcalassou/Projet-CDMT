# -*- coding: utf-8 -*-
"""
Created on Sun Apr 30 11:14:40 2017

@author: Gabriel
"""

"""
Script permettant de lire le fichier d'options et de stocker les différentes données qui
s'y trouve.
"""

class options:
    def __init__(self, path_fichier_option):
        #chemin du fichier d'options
        self.path_fichier_option = path_fichier_option
        
        #resultat de la méthode lisant le fichier d'options
        self.information_fichier = self.lecture_options()
        
        #chemin du dossier contenant les fichiers gps
        self.dossier_gps  = self.information_fichier[0]#'simulations_test\\GPS'
        
         #chemin du fichier slr à exploiter
        self.fichier_slr = self.information_fichier[1]#'simulations_test\\annuel_avec_bruit\\SNXOUT1030.SNX'
        
        #chemin du fichier contenant les coordonnées de référence GPS
        self.fichier_ref_gps = self.information_fichier[2]#simulations_test\\IGS14.ssc'
        
        #chemin du fichier contenant les coordonnées de référence des stations slr
        self.fichier_ref_slr = self.information_fichier[3]#'simulations_test\\SLRF2008_150928_2015.09.28.snx'
        
        #chemin du fichier des déformations post-seismique
        self.psd_slr = self.information_fichier[4]
        
        #chemin du fichier contenant les numéros soln des stations slr
        self.soln_slr = self.information_fichier[5]
        
        #chemin du fichier contenant les correspondances entre les domes et les codes des stations GPS et slr 
        self.fichier_domes = self.information_fichier[6]#'simulations_test\\codomes_coord.snx'
        
        ##chemin du fichier de préférence des stations gps
        self.fichier_preference_gps = self.information_fichier[7]
        
        #seuil pour les points faux gps
        self.seuil_gps = self.information_fichier[8]
        
        #seuil pour les points faux slr
        self.seuil_slr = self.information_fichier[9]
        
        self.seuil_test_2 = 0

    def lecture_options(self):
        """Lecture du fichier d'options pour en extraire les différents paramètres
        
        Entrée
        -- path_fichier_option : chemin du fichier d'options
        
        Sortie:
        -- dossier_gps : chemin du dossier contenant les fichiers gps
        -- fichier_slr : chemin du fichier slr à exploiter
        -- fichier_ref_gps : chemin du fichier contenant les coordonnées de référence GPS
        -- fichier_ref_slr : chemin du fichier contenant les coordonnées de référence des stations slr
        -- psd_slr, soln_slr : chemin du fichier des déformations post-seismique
        -- fichier_domes : chemin du fichier contenant les numéros soln des stations slr
        -- fichier_preference_gps : chemin du fichier contenant les correspondances entre les domes 
                                    et les codes des stations GPS et slr 
        -- seuil_gps : seuil pour les points faux gps
        -- seuil_slr : seuil pour les points faux slr
        """
        fichier = open(self.path_fichier_option, 'r')
        lignes = fichier.readlines()
        for ligne in lignes:
            if ligne == '':
                pass
            ligne = ligne.split()
            if ligne[0]== 'chemin_dossier_gps': 
                try:
                    dossier_gps = ligne[1]
                except:
                    print("Le chemin du dossier du fichier gps n'a pas été trouvé")
            
            elif ligne[0]== 'chemin_fichier_snx': 
                try:
                    fichier_slr = ligne[1]
                except:
                    print("Le fichier slr n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_coordonees_reference_gps':
                try:
                    fichier_ref_gps = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_coordonees_reference_slr':
                try:
                    fichier_ref_slr = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_SOLN':
                try:
                    soln_slr = ligne[1]
                except:
                    soln_slr = ''
                    print("Il n'y a pas de fichier soln")
            elif ligne[0]== 'chemin_fichier_psd':
                try:
                    psd_slr = ligne[1]
                except:
                    psd_slr = ''
                    print("Il n'y a pas de fichier psd")
            elif ligne[0]== 'chemin_fichier_domes':
                try:
                    fichier_domes = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'chemin_fichier_preference_gps':
                try:
                    fichier_preference_gps = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'seuil_gps':
                try:
                    seuil_gps = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
            elif ligne[0]== 'seuil_slr':
                try:
                    seuil_slr = ligne[1]
                except:
                    print("Le fichier n'a pas été trouvé")
        fichier.close()
        
        return dossier_gps, fichier_slr, fichier_ref_gps, fichier_ref_slr, psd_slr, soln_slr, fichier_domes, fichier_preference_gps, seuil_gps, seuil_slr
        