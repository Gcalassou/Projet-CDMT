# -*- coding: utf-8 -*-
"""
Created on Mon May  8 17:12:22 2017

@author: Gabriel
"""

import options as opt
import station_co_loc 
import lecture_fichier_snx
import mise_en_forme 
import slr_coloc
import class_slr

import moindre_carree
"""
Classe récupérant les informations du fichier d'options.

Entrées:
-- path_fichier_option : chemin du fichier d'options

Sortie:
-- dossier_gps : chemin du dossier contenant les fichiers GPS
-- fichier_slr : chemin du fichier slr
-- fichier_ref_gps : chemin du fichier contenant les coordonnées de référence GPS
-- fichier_ref_slr : chemin du fichier contenant les coordonnées de référence SLR
-- psd_slr : chemin du fichier contenant les inforamtions sur les déformations post-seismique
-- soln_slr : chemin du fichier SOLN
-- fichier_domes : chemin du fichier codomes 
-- fichier_preference_gps : chemin du fichier de préférence GPS
-- seuil_gps : valeur du seuil pour le test des points faux GPS
-- seuil_slr : valeur du seuil pour le test des points des points slr        
"""
o = opt.options('simulations_test\\fichier_options.txt')

#chemin_dossier_gps = o.dossier_gps
#chemin_fichier_slr = o.fichier_slr
#chemin_fichier_ref_gps = o.fichier_ref_gps
#chemin_fichier_ref_slr = o.fichier_ref_slr
chemin_psd_slr = o.psd_slr
chemin_soln_slr = o.soln_slr
#chemin_fichier_domes = o.fichier_domes
#chemin_fichier_preference_gps = o.fichier_preference_gps
#seuil_gps_test_point_faux = o.seuil_gps
#seuil_slr_test_point_faux = o.seuil_slr


"""
Classe permettant de lire les différents blocs du fichier snx

Entrée:
-- fichier_slr {sortie classe options} : chemin du fichier slr 

Sortie:
-- bloc_epoch : matrice contenant les informations du bloc epoch
-- bloc_siteid : matrice contenant les informations du bloc site/id
-- bloc_estimate_solution : matrice contenant les informations du bloc estimate_solution
-- matrice_covariance : matrice contenant les informations du bloc estimate_matrix

"""
lfs = lecture_fichier_snx.Laser(o.fichier_slr)

#fichier_snx_bloc_epoch = lfs.bloc_epoch
#fichier_snx_bloc_siteid = lfs.bloc_siteid
#fichier_snx_bloc_estimate_solution = lfs.bloc_estimate_solution
#fichier_snx_matrice_covariance = lfs.matrice_covariance



"""
Classe permettant d'extraire les stations GPS co-localisées

Entrée:
-- dossier_gps {sortie classe options} : chemin du dossier contenant les fichiers GPS
-- bloc_epoch {sortie classe lecture fichier snx} : matrice contenant les informations du bloc epoch
-- fichier_domes {sortie classe options} : chemin du fichier codomes

Parametres intermediaireS : 
-- liste_stations_gps = liste des noms des stations GPS      
-- path_fichier_gps : chemin des fichiers gps contenus dans le dossier

Sortie:
-- stations_GPS_coloc : matrice contenant les informations relatives aux stations GPS co-localisées
"""
slc = station_co_loc.station_co_loc(o.dossier_gps, lfs.bloc_epoch, o.fichier_domes, o.fichier_preference_gps)

#station_coloc_liste_stations_gps = slc.liste_stations_gps
#station_coloc_path_fichier_gps = slc.path_fichier_gps
#
station_coloc_stations_GPS_coloc = slc.stations_GPS_coloc



"""
Classe permettant de renvoyer les vecteurs déplacements et la matrice de covariance des stations
GPS co-localisées.

Entrée:
-- information_station_gps_coloc{classe stations_co_loc}: matrice contenant les informations 
   relatives aux stations GPS co-localisées
-- fichier_coordonnées_référence_gps {classe option} : chemin du fichier contenant les coordonnées de référence GPS

Parametres intermediaires :
-- matrice_coord_ref_gps : matrice contenant les coordonnées de référence des station GPS
-- code_slr_retenu : liste des codes des stations SLR ayant des stations GPS co-localisées
-- code_gps_retenu : liste des noms des stations GPS retenues
-- rotation : liste des matrices rotations associées à chaque stations GPS co-localisées
-- moyenne_coord : 
-- moyenne_cov :

Sortie:
-- vecteur_deplacement : vecteur des déplacements des stations GPS co-localisées
-- matrice_covariance_gps : matrice des covariances des stations GPS co-localisées

"""
org  = mise_en_forme.organisation_data_gps(slc.stations_GPS_coloc, o.fichier_ref_gps)


#organisation_gps_matrice_coord_ref_gps = org.matrice_coord_ref_gps
#organisation_gps_code_slr_retenu = org.code_slr_retenu
#organisation_gps_code_gps_retenu = org.code_gps_retenu
#organisation_gps_matrice_rotation =org.rotation
organisation_gps_moyenne_coord = org.moyenne_coord
#organisation_gps_moyenne_cov = org.moyenne_cov
#organisation_gps_vecteur_deplacement = org.vecteur_deplacement
#organisation_gps_mat_cov_gps = org.matrice_covariance_gps




"""
Classe permettant de créer le vecteur des positions des stations slr et la matrice de covariance
des stations slr co-localisées

Entrée:
-- fichier_slr {sortie classe options} : chemin du fichier slr 
-- code_slr {sortie classe station_co_loc} : liste des stations slr utilisées
-- bloc_estimate_solution {sortie classe lecture fichier snx} : matrice contenant 
                                        les informations du bloc estimate_solution
-- bloc_matrice_cov {sortie classe lecture fichier snx} : matrice contenant les informations du bloc estimate_matrix
                                    
Sortie:
-- vecteur_pos_slr : vecteur des positions des stations slr co-localisées avec le code des stations slr
-- matrice_cov_slr : matrice de covariance des stations slr co-localisées                                       
"""
slrc = slr_coloc.slr_coloc(o.fichier_slr, org.code_slr_retenu, lfs.bloc_estimate_solution, lfs.matrice_covariance)

vecteur_pos_slr = slrc.vecteur_pos_slr
mat_cov_slr = slrc.matrice_cov_slr
#test_vecteur_position_slr = slrc.vecteur_pos_slr
#test_matrice_cov_slr = slrc.matrice_cov_slr


"""Script permettant de calculer les coordonnées de référence d'une station laser à partir des 
mesures réalisées pour l'établissement de l'ITRF 2014.

Entrée:
-- path_ref {class options}: chemin du fichier contenant les coordonnées de référence SLR
-- path_psd {class options}: chemin du fichier contenant les inforamtions sur les déformations post-seismique
-- path_soln {class options}: chemin du fichier SOLN
-- liste_stations_slr {classe mises à jour}: liste des numéro des stations slr obtenue pour 
                        le calcul des moindres carrées
-- bloc_epoch_slr {sortie classe lecture fichier snx} : matrice contenant les informations du bloc epoch

Parametres intermediaires :
-- bloc_solution_psd : matrice contenant les inforamtions du bloc solution du fichier psd
-- fichier_soln : matrice contenant les informations sur les soln
-- coord_ref_slr : matrice contenant les informations du bloc epoch du fichier 
                    des coordonnées de référence
-- matrice_tmean : matrice contenant les t moyens des periodes de mesure des stations laser
-- matrice_soln : matrice contenant les numéros soln associés aux codes des stations slr
                  et de leurs points
-- matrice_info_coord_ref : matrice contenant les informations permettant de calculer les coordonnées de références 
                            des stations slr retenues
-- coord_sans_trie : matrice contenant les coordonnées de référence des différentes stations slr retenues
                     le format de sortie et l'ordre des stations ne convient pas encore au calcul des MC

Sortie : 
-- coord_avec_trie : vecteur des coordonnées de référence des stations laser avec leurs codes de stations
                     associées
"""
cs = class_slr.SLR(o.fichier_ref_slr,o.soln_slr, o.psd_slr, org.code_slr_retenu, lfs.bloc_epoch)

#ref_bloc_solution_psd = cs.bloc_solution_psd
#ref_fichier_soln = cs.fichier_soln
#ref_coord_ref_slr = cs.coord_ref_slr
#ref_matrice_tmean = cs.matrice_tmean
#ref_matrice_soln = cs.matrice_soln
ref_matrice_info_coord_ref = cs.matrice_info_coord_ref
#ref_coord_sans_trie = cs.coord_sans_trie

ref_coord_avec_trie = cs.coord_avec_trie




"""Script permettant d'effectuer le calcul de moindre carrée et d'estimer le déplacement des 
stations laser avec la valeur d'erreur

Entrée :
-- vecteur_deplacement_gps : vecteur des déplacements des stations GPS co-localisées
-- code_slr_gps : liste des codes slr correspondant au vecteur de déplacement GPS
-- vecteur_coord_ref_slr : vecteur des coordonnées de référence slr
-- code_slr_ref : liste des codes slr correspondant au vecteur des positions des stations slr de référence
-- vecteur_pos_slr : vecteur des positions des stations slr co-localisées 
-- code_slr_pos : liste des codes slr correspondant au vecteur des positions des stations slr
-- matrice_cov_gps : matrice des covariances des stations GPS co-localisées
-- matrice_cov_slr : matrice de covariance des stations slr co-localisées
-- seuil : valeur du seuil pour le test des points des points slr 

Paramètres intermédiaires :
-- matriceA : matrice A des moindres carrées
-- matriceB : matrice des observations des moindres carrées
-- matrice_poids : matrice de poids des moindres carrées
-- matriceN : matrice normale des moindres carrées
-- matriceK : matrice K des moindres carrées
-- matriceX : matrice des observations des moindres carrées
-- residus : matrice des résidus des moindres carrées
-- sig : facteur unitaire de variance des moindres carrées
-- matV : matrice de variance des résidus
-- matXc : matrice de variance des solutions
-- X_after_test : matrice des solutions des moindres carrées après le test des points faux
-- matriceA_after_test : matrice A des moindres carrées après le test des points faux
-- matriceP_after_test : matrice de poids des moindres carrées après le test des points faux
-- nbr_iteration : le nombre d'itérations effectuer lors du test des points faux

Sortie :
-- dX : matrice contenant les déplacements des stations laser
-- dCov : matrice contenant les écarts-types des stations laser
"""


mc = moindre_carree.calcul_MC(org.vecteur_deplacement, cs.coord_avec_trie, slrc.vecteur_pos_slr, org.matrice_covariance_gps, slrc.matrice_cov_slr, o.seuil_slr)

mc_xref = mc.vecteur_coord_ref_slr
mc_xgps = mc.vecteur_deplacement_gps
mc_xslr = mc.vecteur_pos_slr
#
#mc_matriceA = mc.matriceA
mc_matriceB = mc.matriceB
#mc_matriceP = mc.matrice_poids
#mc_matriceN = mc.matriceN
#mc_matriceK = mc.matriceK
#mc_matriceX = mc.matriceX
#mc_residus = mc.residus
#mc_sigma = mc.sig
#mc_matV = mc.matV
#mc_matXc = mc.matXc
#mc_X_after_test = mc.X_after_test
mc_A_after_test = mc.matriceA_after_test
#mc_P_after_test = mc.matriceP_after_test
#mc_nombre_itération = mc.nbr_iteration
#
mc_dX = mc.dX
mc_dCov = mc.dCov


