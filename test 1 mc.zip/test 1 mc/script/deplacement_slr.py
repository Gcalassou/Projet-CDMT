# -*- coding: utf-8 -*-
"""
Created on Mon May  8 20:54:35 2017

@author: Gabriel
"""

import numpy as np 
import moindre_carree as mc

"""
Ce script calcule les déplacements SLR des stations slr 
co-localisées

Entrée:
-- xslr :
-- xref :
-- xgps : 
-- sol_mc :
-- matrice_a :
-- sigma : 
-- poids :  
-- pos_slr : 
-- cov_slr : 
-- cov_gps : 


Sortie 
-- deltaX : 
-- delta_cov : 
-- rapport : 
"""

class deplacement:
    def __init__(self):
        self.xslr=0
        self.xref=0
        self.x_gps = 0
        self.sol_mc = 0
        self.matrice_a =0
        self.sigma = 0
        self.poids = 0
        self.matrice_normale = np.dot(np.transpose(self.matrice_a), np.dot(self.poids, self.matrice_a))
        self.pos_slr = 0
        self.cov_slr = 0
        self.cov_gps = 0
    
    def facteur(self):
        A = self.matrice_a
        P= self.poids
        N = self.matrice_normale
        temp = np.dot(A, np.dot(np.linalg.inv(N),np.dot(np.transpose(A), P)))
        return temp
        
    def deltaX(self):
        I = np.eye(self.matrice_a.shape[0])
        temp1 = np.dot((I - self.facteur), self.xslr)
        temp2 = np.dot(self.facteur, self.x_gps )
        temp3 = np.dot((I - self.facteur), self.xref)
        resultat = temp1 + temp2 + temp3
        return resultat
        
    def delta_cov(self):
        I = np.eye(self.matrice_a.shape[0])
        C = I- self.facteur
        D = self.facteur
        temp1 = np.dot(C, np.dot(self.cov_slr, np.transpose(C)))
        temp2 = np.dot(D, np.dot(self.cov_gps, np.transpose(D)))
        resultat = temp1 + temp2
        return resultat
        
    
        
        