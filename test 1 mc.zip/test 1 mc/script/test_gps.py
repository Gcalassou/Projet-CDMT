# -*- coding: utf-8 -*-
"""
Created on Sat Apr  8 10:53:16 2017

@author: Gabriel
"""

import Ftp as ftp
import numpy as np
import fich_gps as gps
import epoch
import fichier_ref as ref
import DOMES as domes
import os

class test1():
    def __init__(self, chemin, station, gps):
        self.station = station
        self.gps = gps
        self.path = 'IGS14.ssc'
        self.file_laser= []
        self.time_laser = 0
        self.chemin = chemin
        
        
    def coord_ref_gps(self):
        """Fonction permettant les coordonées GPS approchées en fonction d'une station laser
        parametres
        -- coord : liste des coordonnées extraite du fichier snx voulu
        
        return 
        -- x_gps : coordonnées de la station gps en x
        -- y_gps : coordonnées de la station gps en y
        -- z_gps : coordonnées de la station gps en z
        """
        tt = False
        coord = ref.lecture_fichier_ref(self.path)
        d=domes.DOMES('GPS',self.station)
        domes_test = d.conversion()
        dd= domes.DOMES('Laser',domes_test[:5])
        liste_domes = dd.conversion()
#        print(liste_domes)
        for i in range(len(coord)):
            if coord[i][0] in liste_domes:
                x_gps = coord[i][1]
                y_gps = coord[i][2]
                z_gps = coord[i][3]
                tt= True                
                break
            
        if tt:
            return x_gps, y_gps, z_gps
        else:
            print('station non trouvé')
            
            
    def recherche_laser(self):
        """Fonction permettant de rechercher la liste des fichiers laser sur une semaine
        parametres : 
        -- chemin : emplacement du fichier {string}
        -- station : station laser d'étude {string}
        
        return : liste des noms des fichiers voulu
        """
        # liste contenant les fichiers lasers récement MaJ
        liste_fichier = os.listdir(self.chemin)
        
        #boléen permettant d'identifier la station la plus vieille de la semaine
        station_test = False 
        
        #on stocke les fichiers dont les stations slr sont présentent
        liste_station_valide = [] 
        
        for i in range(len(liste_fichier)):
            
            for value in epoch.lecture_EPOCH(self.chemin+liste_fichier[i]):
                
                if value[0] == self.station:
                    
                    if station_test == False:
                        
                        date_debut = value[1] #on garde en memoire la date de début des mesures
                        station_test = True
#                        print('ok')
                        liste_station_valide += [liste_fichier[i]]
                    
                    else:
                        
                        if  float(value[2])-float(date_debut) < 7: 
                            
                            liste_station_valide += [liste_fichier[i]]
                            
        return liste_station_valide
        
    def coord_ref_slr(self, fichier):
        """Fonction récupérant les coordonnées approchées d'une station slr
        
        """
        # on récupère l'ensemble des coordonnées approchées des stations slr 
        # contenu dans un fichier snx
        coord = ref.lecture_fichier_ref_enh(self.chemin+fichier)
        
        for i in range(len(coord)):
            
            if coord[i][0]== self.station:
                
                x = coord[i][1]
                y = coord[i][2]
                z = coord[i][3]
                break
                
        return x,y,z
    
    def liste_coord_slr(self):
        """Fonction calculant la moyenne des coordonnées des station slr sur la semaine
        
        
        """
        fichiers = self.recherche_laser()
        debut, fin = 1*10**100,-1*10**100
        liste_jours = []
        liste_temps= []
        mat_coord = np.zeros((len(fichiers),3))
        for i in range(len(fichiers)):
            coord = self.coord_ref_slr(fichiers[i])
            mat_coord[i] = [coord[0], coord[1], coord[2]]            
            
            for value in epoch.lecture_EPOCH(self.chemin+fichiers[i]):
                if value[0] == self.station:
                    if float(value[1])< float(debut):
                        debut = float(value[1])
                    if float(value[2])> float(fin) :
                        fin = float(value[2])
                 
                    liste_temps += [[float(value[1]), float(value[2])]]
        k = debut
        print(type(k), type(fin))
        while k< int(fin +1):
            liste_jours += [int(k)]
            k +=1
        mat_coeff = np.zeros((len(fichiers),len(liste_jours)))
        mat_coeff2 = np.zeros((len(fichiers),len(liste_jours)))
        result = np.zeros((4,len(liste_jours)))
        
        c=0
        for i in range(len(liste_temps)):        
            for j in range(len(liste_jours)):
                if liste_temps[i][0]-liste_jours[j]<1 and liste_temps[i][0]-liste_jours[j]>0:
                    c+=1
                    mat_coeff[i][j]=1-(liste_temps[i][0]-liste_jours[j])
                    if liste_temps[i][1]-liste_jours[j]<1:
                        mat_coeff[i][j]=mat_coeff[i][j]+liste_temps[i][1]-liste_jours[j]-1
                elif liste_temps[i][1]-liste_jours[j]<1:
                    mat_coeff[i][j]=(liste_temps[i][1]-liste_jours[j])
                elif liste_temps[i][0]-liste_jours[j]>1:
                    mat_coeff[i][j]= 0
                else:
                    mat_coeff[i][j] = 1
        for i in range(mat_coeff.shape[1]):
            maxi = sum(mat_coeff[:,i])
            for j in range(mat_coeff.shape[0]):
                mat_coeff2[j][i] = mat_coeff[j][i]/maxi
        result[0] = [n+0.5 for n in liste_jours]
        for i in range(mat_coeff.shape[1]):
            for j in range(mat_coeff.shape[0]):
                result[1][i] += mat_coeff2[j][i]*mat_coord[j][0]
                result[2][i] += mat_coeff2[j][i]*mat_coord[j][1]
                result[3][i] += mat_coeff2[j][i]*mat_coord[j][2]
#        return liste_temps, debut , fin, liste_jours, mat_coeff2, result
        print(mat_coeff)
        return result
        
            
    def co_laser(self):
        if self.file_laser == []:
            test = ftp.Ftp('ftp2.ign.fr',['simulations','annuel_avec_bruit'],'ing2-geocentre','Eiguceuqu0Yiu8wa' )
            self.file_laser += test.connexion_download_sinex('', self.station)[0]
            self.time_laser = test.connexion_download_sinex('', self.station)[1]
            
    def coord_gps(self,coord):
        """Fonction permettant de récupérer les coordonnées gps correspondant aux coordonnées slr
        
        A généraliser
        """
#        print('étape 1')
#        self.co_laser()
        coord_gps_utile = np.zeros((7,3))
        sigma_utile = np.zeros((7,3))
#        print('étape 2')
        coord_slr = self.liste_coord_slr()
        days = coord_slr[0]
        cref = self.coord_ref_gps()
#        print(cref)
        g = gps.calc(cref[0] ,cref[1] ,cref[2] ,'ZECK_igs_IGS.res')
        coord_gps, time_gps = g.matc
        sig = g.d_sigma_enh()
        compteur =0
        for i in range(time_gps.shape[0]):
#            print(days[-1]-time_gps[i])
            if days[-1]-time_gps[i]<=7 and days[-1]-time_gps[i]>0:
                
#                print('compteur : '+str(compteur))
                coord_gps_utile[compteur] = coord_gps[i]
                sigma_utile[compteur] = sig[i]
                compteur +=1
#        print(len(coord_gps_utile))
        moy = g.moy_pond(coord_gps_utile, sigma_utile, coord)
        return coord_gps_utile, moy, sigma_utile
        
    def test_composante(self, seuil,coord):
        print("Test sur la composante en "+coord)
        if coord == "E":
            coord_num = 1
        elif coord == "N":
            coord_num = 2
        elif coord == "H":
            coord_num = 3
        moy =  self.coord_gps(coord)[1] 
        coord_slr = self.liste_coord_slr()[coord_num]
        P = []
        rejet = []
        for value in coord_slr:
            P += [abs(value/moy)]
        for i in range(len(P)):
            if P[i] > seuil:
                rejet += [P[i], i]
        return P, rejet  
        
                
        
                
                
#    
#    def test_1(self):
#        coord_ref
#        calcul= gps.calc
                
if __name__ == '__main__':
    chemin = 'simulations_test\\annuel_avec_bruit\\'
    chemin2 = 'simulations_test\\GPS\\'
    test = test1(chemin, '1889',chemin2+'ZECK_igs_IGS.res')
    station_rechercher = test.recherche_laser()
    moy_temps = test.liste_coord_slr()
    coord = test.coord_gps("E")
#    flag_x = test.test_composante(10000, "E")
#    flag_y = test.test_composante(10000, "N")
#    flag_z = test.test_composante(10000, "H")
#    print(coord)
#    cslr = test.coord_ref_slr('SNXOUT1001.SNX')
#    coord = test.coord_ref_gps()
#    gpps= test.coord_gps()