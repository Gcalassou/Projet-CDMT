# -*- coding: utf-8 -*-
"""
Created on Sun Apr 30 10:29:20 2017

@author: Gabriel
"""
import script_test1 as sc1
import scipt_test2 as sc2

def main():
    scc1 = sc1.test1()
#    scc2 = sc2.test2()
    print(scc1.var3)
#    sc = scc2.chg()
    print(scc1.var1,scc1.var2,scc1.var3)
#    print(sc)
    scc1.change()
    print(scc1.var1,scc1.var2,scc1.var3)
#    sc = scc2.chg()
#    print(sc)
    print(sc2.var1, sc2.var2)
    sc2.change()
    print(sc2.var1, sc2.var2)
    print(scc1.tttt())
    
    
    
if __name__ == '__main__':
    main()