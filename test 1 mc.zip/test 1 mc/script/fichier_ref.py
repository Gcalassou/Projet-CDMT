# -*- coding: utf-8 -*-
"""
Created on Wed Mar 15 15:50:18 2017

@author: dpts
"""
import math
import convert

def convert_lat(deg,minu,sec):
    """
    Convertie des latitudes en degres, minutes, secondes en degres decimaux
    """
    DD= float(sec)/3600 + float(minu)/60 + float(deg)
    return DD 
    
def convert_lon(deg ,minu ,sec):
    """
    Convertie des longitudes en degres, minutes, secondes en degres decimaux
    """
    DD= float(sec)/3600 + float(minu)/60 + float(deg)
    return DD
    
def geo_to_cart(lon,lat,h):
        """
        Conversion de coordonées géographiques à cartésiennes
        Arguments :
            - lon : longitude (rad)
            - lat : latitude (rad)
            - h : hauteur (m)
        """
        a = 6378137.0      
        e2 = 0.006694380022
        N = a / math.sqrt(1.0 - e2*(math.sin(lat))**2)        # angles in rad
        X = (N+h) * (math.cos(lon)) * (math.cos(lat))
        Y = (N+h) * (math.sin(lon)) * (math.cos(lat))
        Z = (N*(1-e2) + h) * (math.sin(lat))
	
        return X,Y,Z

def lecture_fichier_ref(file):
    """Fonction permettant d'extraire les coordonnées de références de stations GPS dans le 
    bloc site id 
    
    Entrée : 
    -- file : fichier dans lequel se trouve les coordonnées de références des différentes 
              stations GPS permettant le calcul de l'ITRF
              
    Sortie : 
    -- liste : liste de listes où chaque sous-liste contient les informations suivantes:
               [code station GPS, {longitude} [degres, minutes, secondes], {latitude}[degres, minutes, secondes],
               altitude]
    """
    
    #lecture du fichier de référence gps
    fichier=open(file,'r')
    lignes=fichier.readlines()
    i=0
    liste=[]
    
    #on parcours le fichier
    for ligne_test in lignes:
        
        if ligne_test[0:8] =='+SITE/ID':
            
            j=i+2
            while ((lignes[j]).split())[0]!='-SITE/ID':
                
                code=lignes[j][1:5]            #code de la station 
                lon=lignes[j][44:55]           #longitute en deg min sec
                lon_deg = lon[0:3]
                lon_min = lon[4:6]
                lon_sec = lon[7:11]

                #on extrait les infos sur la latitude
                lat_deg=lignes[j][56:59]        
                lat_min=lignes[j][59:62]
                lat_sec=lignes[j][62:67]

                alti=lignes[j][69:75] 
                
                #on stocke les différentes informations
                liste+=[[code,[lon_deg,lon_min,lon_sec],[lat_deg,lat_min,lat_sec],alti]]
                j+=1
            break
      
        i+=1
    fichier.close()
    return liste

def lecture_fichier_ref_xyz(file):
    """Permet de renvoyer les coordonnées de références des stations GPS en coordonnées
    cartesiennes
    
    """
    liste = []
    lect = lecture_fichier_ref(file)
    for i in range(len(lect)):
        #on passe la latitude et la longitude de degres decimaux
        lon_r = convert_lon(lect[i][1][0],lect[i][1][1],lect[i][1][2])
        lat_r = convert_lat(lect[i][2][0],lect[i][2][1],lect[i][2][2])
        
        #on convertie les coordonnées de références en coordonnées cartésiennes
        X=geo_to_cart(float(lon_r),float(lat_r),float(lect[i][3]))[0]
        Y=geo_to_cart(float(lon_r),float(lat_r),float(lect[i][3]))[1]
        Z=geo_to_cart(float(lon_r),float(lat_r),float(lect[i][3]))[2]
        liste+=[[lect[i][0],X,Y,Z]]
    return liste
    
def lecture_fichier_ref_enh(file):
    """Permet de renvoyer les coordonnées de références des stations GPS en coordonnées
    geographique
    
    """
    liste = []
    lect = lecture_fichier_ref(file)
    for i in range(len(lect)):
        lon_r = convert_lon(lect[i][1][0],lect[i][1][1],lect[i][1][2])
        lat_r = convert_lat(lect[i][2][0],lect[i][2][1],lect[i][2][2])

        E, N, h = convert.Converter("Lambert 93").geo_to_EN(float(lon_r), float(lat_r), float(lect[i][3]))
        liste += [[lect[i][0], E,N,h]]
    return liste
    
#var=lecture_fichier_ref('IGS14.ssc')
#var=lecture_fichier_ref('ilrsa.pos+eop.150101.v135.snx')
#var2 = lecture_fichier_ref_xyz('ilrsa.pos+eop.150101.v135.snx')



