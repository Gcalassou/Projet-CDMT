# -*- coding: utf-8 -*-
"""
Created on Sat May 13 16:31:45 2017

@author: Gabriel
"""
import numpy as np 

class fichier_psd:
    def __init__(self, path):
        #chemin du fichier contenant les déformations post-seismique
        self.path = path
#        self.site_id = self.lecture_ID()
        self.estimate_solution = self.lecture_solution()
#        self.matrice_covariance = self.lecture_matrice_cov()

    def lecture_ID(self):
        fichier=open(self.path,'r')
        lignes=fichier.readlines()
        i=0
        liste=[]
        for ligne in lignes:
            ligne=ligne.split()
            if ligne[0]=='+SITE/ID':
                j=i+2
                while ((lignes[j]).split())[0]!='-SITE/ID':
                    ligne_test=lignes[j].split()
                    code=ligne_test[0]
                    DOMES=ligne_test[2]
                    liste+=[[code,DOMES]]
                    j+=1
            i+=1
        
        return(liste)
        
    def lecture_solution(self):
        """Fonction permettant de lire le bloc "SOLUTION/ESTIMATE"
        
        parametres
        fichier = fichier contenant les déformations seismique
        
        sortie
        -- liste : liste des données contenus dans le bloc
        -- j-(i+2) : renvoi le nombre d'éléments de la liste
        """
        fichier=open(self.path,'r')
        lignes=fichier.readlines()
        i=0
        liste=[]
        for ligne in lignes:
            ligne_test=ligne.split()
            
            if ligne_test[0] =='+SOLUTION/ESTIMATE':
                j=i+2
                while ((lignes[j]).split())[0]!='-SOLUTION/ESTIMATE':
                                        
                    type_data = (lignes[j])[7:13]
                    
                    code = (lignes[j])[14:18]
#                    print('test'+str(code))
                    epoch = (lignes[j])[27:39]
                    estimate_sol = float((lignes[j])[47:69])
                    liste+=[[type_data, code, epoch,estimate_sol]]
                    j+=1
                break
            i+=1
        return liste
        
    def lecture_matrice_cov(self):
        """Fonction permettant de lire le bloc "SOLUTION/MATRIX_ESTIMATE"
        
        sortie 
        -- mat : matrice contenant l'ensemble des données du bloc en question
        """
        fichier=open(self.path,'r')
        lignes=fichier.readlines()
        dim=self.lecture_solution()[1]
#        print(dim)
        mat=np.zeros((dim,dim))
#        print(mat.shape)
        i=0
        for ligne in lignes :
            ligne=ligne.split()
            if ligne[0]=='+SOLUTION/MATRIX_ESTIMATE':
                j=i+2
                
                while ((lignes[j]).split())[0]!='-SOLUTION/MATRIX_ESTIMATE':
                    temp=[]
                    ligne_test=lignes[j].split()
                    PAR1=int(ligne_test[0])
#                    print(PAR1)
                    PAR2=int(ligne_test[1])
                    #print(PAR2)
                    temp=ligne_test[2:]
                    for i in range(len(temp)):
                        mat[PAR1-1][PAR2+i-1]=temp[i]
                    
                        
                    
                    j+=1
            i+=1
        return mat
        
if __name__ == '__main__':
    psd = fichier_psd('simulations_test/psd_slr.txt')
    sol = psd.estimate_solution