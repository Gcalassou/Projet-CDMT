# -*- coding: utf-8 -*-
"""
Created on Wed Mar 15 16:48:16 2017

@author: Gabriel
"""

import numpy as np
def test():
    liste=['1','abc','2','3']
    li=['1']
    i=0
    print(liste[:2])
    print(li[:2])
    while i < len(liste):
        try:
            int(liste[i])
            
        except ValueError:
            del liste[i]
            i-=1
        i+=1
    print(liste)
    
#test()
    
def test2():
#    coord = [-1.64, -1.61, -1.59]
    coord = [-2.0,-2.0]
#    p = [0.695139/0.01**2,1/0.01**2, 0.98611/0.01**2]
    p=[0.7118/0.01**2, 0.9125/0.01**2]
    sigma =[0.01, 0.01, 0.01]
    alpha = [0.695139, 1, 0.98611]
    s = np.sum(p)
    s2=0
    for i in range(len(p)):
        s2 += p[i]*coord[i]
    moy = (1/s)*s2
    s3=0
    for j in range(len(p)):
        s3 += ((coord[i]-moy)**2)*p[i]
    return 1/s, s2, moy, np.sqrt((1/s)*s3), s3
    
print(test2())