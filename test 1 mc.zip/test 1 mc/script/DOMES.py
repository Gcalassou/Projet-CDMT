# -*- coding: utf-8 -*-
"""
Created on Wed Mar 15 10:21:16 2017

@author: Gabriel
"""

"""Script permettant de faire le lien entre les DOMES des stations laser et les codes des 
stations GPS et vice versa

"""
class DOMES:
    def __init__(self,type_data,number, path):
        self.type_data=type_data
        self.number=number
        self.path= path
        self.lecture_fichier = self.lecture_data()
        
    def lecture_data(self):
        """Lecture du fichier 'codomes'
        
        Entrée:
        -- path : chemin du fichier codomes
        
        Sortie:
        -- code : liste contenant les listes de code GPS 
        -- domes : liste contenant les codes domes des stations laser
        """
        fichier = open(self.path, 'r')
        lignes = fichier.readlines()
        code, domes=[],[]
        for ligne in lignes:
            ligne= ligne.split()
            code += [ligne[0]]
            domes+= [ligne[2]]
        return code, domes
        
    def conversion(self):
        """Fonction permettant de faire le lien entre les codes DOMES et les codes GPS 
        et vice versa.
        
        Entrée
        -- liste_code_domes : liste des codes GPS et domes présent dans le fichier codomes
        
        Sortie 
        -- code_gps : code gps associé au code domes en entré
        -- liste_laser : liste des codes gps associée au code domes en entré
        """
        liste_code_domes=self.lecture_fichier
        liste_laser=[]
        
        #cas où on recherche le code DOMES des stations laser
        #donnée en entrée : code GPS
        if self.type_data=="GPS":
            i=0
            for value in liste_code_domes[0]:
                
                if value[:5] == self.number:
                    code_gps = liste_code_domes[1][i]
                    return code_gps
                    break
                i+=1
                
        # cas où on recherche les codes GPS
        #donnée en entrée : code DOMES de la station laser
        if self.type_data=="Laser":
            i=0
            for value in liste_code_domes[1]:
                
                if value[:5] == self.number:
                    liste_laser += [liste_code_domes[0][i]]
                i+=1
            return liste_laser
            
if __name__ == '__main__':
    test = DOMES("GPS", "1890", 'simulations_test\\codomes_coord.snx')
    print(test.conversion())
    
#    test2= DOMES("Laser", "42202", 'simulations_test\\codomes_coord.snx')
    test2= DOMES("Laser", test.conversion()[:5], 'simulations_test\\codomes_coord.snx')
    mat_Domes= test.lecture_data()
#    print(mat_Domes[:,0])
#    print(test.conversion())
    print(test2.conversion())
                