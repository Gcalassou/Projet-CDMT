# -*- coding: utf-8 -*-
"""
Created on Sun Apr 30 10:28:53 2017

@author: Gabriel
"""

#import script_test1 as sc1

#class test2():
#    def __init__(self):
#        self.var4 = 0
#    def chg(self):
#        scc1 = sc1.test1()
#        test= scc1.var1 + scc1.var2
#        return test
var1 = 1
var2 = 18

def change():
    global var1 
    var1 = 9
    global var2 
    var2 =11
#    return var1
    
    
#print(var1,var2)
#change()
#print(var1,var2)