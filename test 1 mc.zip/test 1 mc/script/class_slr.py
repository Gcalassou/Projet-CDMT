# -*- coding: utf-8 -*-
"""
Created on Tue May  2 21:10:36 2017

@author: Oumaïma
"""

"""Ce script permet de calculer les coordonnées réf à la bonne date. 
 


Entrée:
-- chemin fichier psd SLR : chemin du fichier contenant les différentes infos postsimiques touchant certaines stations SLR
-- chemin fichier Soln SLR : chemin du fichier contenant les numéros Soln des stations SLR
-- chemin fichier coord ref SLR : chemin du fichier contenant les coord ref SLR 
-- bloc EPOCH du fichier snx : matrice contenant les informations nous intéressant du bloc "SOLUTION/EPOCHS"

Sortie:
--

"""

from astropy.time import Time
from lecture_fichier_snx import Laser
import numpy as np
#from post_seismic import seismic 
from convert import Converter as C
import conversion as conv

class SLR:
    
    def __init__(self,path_coor_ref_slr,path_soln,path_psd, liste_stations_slr, bloc_epoch_slr):
        #chemin du fichier comportant les coordonnées de référence de stations laser
        self.path_ref=path_coor_ref_slr#'simulations_test/ITRF2014-ILRS-TRF.SNX'
        
        #chemin du fichier contenant les SOLN
        self.path_soln=path_soln
        
        #chemin du fichier contenant les déformations post-seismique
        self.path_psd=path_psd
        
        #liste des stations slr co-localisées
        self.liste_stations_slr = liste_stations_slr
        
        #matrice contenant les inforamtions du bloc epoch du fichier snx
        self.bloc_epoch_slr = bloc_epoch_slr
        
        #matrice contenant les inforamtions du bloc solution du fichier psd
        self.bloc_solution_psd = self.lecture_solution_psd(self.path_psd)
        
        #matrice contenant les informations sur les soln
        self.fichier_soln=self.Soln()
        
        #matrice contenant les inforamtions du bloc epoch du fichier des coordonnées de référence
        self.coord_ref_slr=self.Coord_ref()[0]
        
        #matrice contenant les t moyens des periodes de mesure des stations laser
        self.matrice_tmean=self.tmean_mesure()
        
        #matrice contenant les numéros soln associés aux codes des stations slr et de leurs points
        self.matrice_soln=self.recup_soln()
        
        #matrice contenant les informations permettant de calculer les coordonnées de références 
        #des stations slr retenues
        self.matrice_info_coord_ref=self.info_coord_ref()
        
        #matrice contenant les coordonnées de référence des différentes stations slr retenues
        #le format de sortie et l'ordre des stations ne convient pas encore au calcul des MC
        self.coord_sans_trie = self.coord_date()
        
        #on réarrange les coordonnées de références de manière à pouvoir les exploiter dans le calcul
        #des MC. Le format de sortie est une matrice de dimension (3*stations, 2) --> [code, composante_xyz]
        self.coord_avec_trie = self.tri_coord_ref(self.liste_stations_slr, self.coord_sans_trie)
    


        
    
    
    def Soln(self):
        """
        Fonction permettant de lire le bloc EPOCHS d'un fichier SLR
        
        Entrée:
        -- fichier soln slr : fichier snx
        
        Sortie: 
        -- mat_resultat : matrice dont chaque ligne contient : 
                          [code station,SOLN,date de début d'acquisition {MJD}, 
                          date de fin d'acquisition{MJD} ]
        """
        try:
            #lecture du fichier snx
            fichier=open(self.path_soln,'r')
            lignes=fichier.readlines()
            
            #indice de la ligne du fichier
            i=0
            
            #liste contenant les lignes du fichier qui nous interessent (celles avec P)
            liste=[]
            
            #matrice contenant les infos souhaitees
            mat_resultat=np.array([[]])
            
            #on parcourt les lignes jusqu'à trouver le bloc 'SOLUTION/DISCONTINUITY'
            for ligne in lignes:
                ligne=ligne.split()
                if ligne[0]=='+SOLUTION/DISCONTINUITY':
                    #indice des lignes au sein du bloc qui nous interesse 
                    j=i+1
                    #on parcourt le bloc qui nous interesse pour y stocker les informations qui nous interessent
                    while ((lignes[j]).split())[0]!='-SOLUTION/DISCONTINUITY':
                        ligne_t=lignes[j]
                        #test pour garder les lignes du bloc contenant 'P'
                        if ligne_t[42:43]=='P':
                            liste+=[((lignes[j]).split())[0:7]]
              
                        j+=1
                i+=1
            #on parcourt notre liste pour y extraire les informations cherchées
            for i in range(len(liste)):
                #code station slr
                code=liste[i][0]
                #soln station slr
                soln=liste[i][2]
                    
                   
                if liste[i][4]=='00:000:00000':
                    #les dates de début de la période SOLN à -infini sont ramenees a 0
                    t_init=0
                    
                    t_fin=self.convert(liste[i][5])
                    t_f=Time(t_fin)
                    t_f.format='mjd'
                    #on stocke dans cette liste les codes,soln,t_i,t_f pour chaque station
                    liste_temp=np.array([[int(code),int(soln),t_init,float(t_f.value)]])
                
                elif liste[i][5]=='00:000:00000' :
                    #les dates de fin periode SOLN convertis en MJD    
                    t_init=self.convert(liste[i][4])
                    t_i=Time(t_init)
                    t_i.format='mjd'
                    #les dates de  fin de période SOLN à + infini sont ramenees a 1000000
                    t_fin=1000000
                    #on stocke dans cette liste les codes,soln,t_i,t_f pour chaque station
                    liste_temp=np.array([[int(code),int(soln),float(t_i.value),t_fin]])
                    
                # le cas ou les dates de periode soln ne sont pas infinies  
                else:
                   # les dates de periode sont convertis aussi en MJD
                   t_i=self.convert(liste[i][4])
                   t_init=Time(t_i)
                   t_init.format='mjd'
                   t_f=self.convert(liste[i][5])
                   t_fin=Time(t_f)
                   t_fin.format='mjd'
                   #on stocke dans cette liste les codes,soln,t_i,t_f pour chaque station
                   liste_temp=np.array([[int(code),int(soln),float(t_init.value),float(t_fin.value)]])
                if mat_resultat.shape == (1,0):
                   mat_resultat = liste_temp
                else:
                   mat_resultat = np.concatenate((mat_resultat, liste_temp))
    
                    
            return(mat_resultat)
        except:
            return []
    
    
    
    
        
    
     
    def Coord_ref(self):
        """
        Fonction permettant de lire le bloc EPOCHS d'un fichier SLR
        
        Entrée:
        -- fichier coord ref SLR : fichier snx
        
        Sortie: 
        -- mat_resultat : matrice dont chaque ligne contient : 
                          [code station,STAX,STAY,STAZ,VELX,VELY,VELZ,
                          SOLN, Mean_Epoch(MJD),Point]
        """
    
        #lecture du fichier snx
        fichier=open(self.path_ref,'r')
        lignes=fichier.readlines()
        
        #indice de la ligne du fichier
        i=0
        
        #matrice conteant les infos souhaitees
        mat_resultat=np.array([[]])
        
        #on parcourt les lignes jusqu'à trouver le bloc 'SOLUTION/ESTIMATE'
        for ligne in lignes:
            ligne=ligne.split()
            
            if ligne[0] =='+SOLUTION/ESTIMATE':
                #indice de la ligne du bloc parcourut 
                j=i+2

                #on parcourt le bloc qui nous interesse pour y stocker les informations qui nous interessent    
                while ((lignes[j]).split())[0]!='-SOLUTION/ESTIMATE':
                    ligne_test=lignes[j].split()
                    #code station slr
                    code=ligne_test[2]
                        
                    #X,Y,X de la station slr
                    STAX=float((lignes[j].split())[8])
                    STAY=float((lignes[j+1].split())[8])
                    STAZ=float((lignes[j+2].split())[8])
                    
                    #vx,vy,vz de la station slr
                    VELX=float((lignes[j+3].split())[8])
                    VELY=float((lignes[j+4].split())[8])
                    VELZ=float((lignes[j+5].split())[8])
                    
                    #SOLN de la station slr
                    SOLN=ligne_test[4]
                    
                    #REF_EPOCH convertit en MJD 
                    EPOCH=self.convert(ligne_test[5])  
                    ref_epoch=Time(EPOCH)
                    ref_epoch.format='mjd'
                    
                    #PT de la station slr
                    Point=ligne_test[3]
                    
                    #stockage des informations 
                    liste_temp=np.array([[int(code),STAX,STAY,STAZ,float(VELX),float(VELY),float(VELZ),float(SOLN),float(ref_epoch.value),Point]])
                    if mat_resultat.shape == (1,0):
                        mat_resultat = liste_temp
                    else:
                        mat_resultat = np.concatenate((mat_resultat, liste_temp))
                    
                
                    j+=6
                
                break
            i+=1
        return mat_resultat,j-(i+2)
    
    
    def tmean_mesure(self):
        """Fonction permettant de recuperer les codes,mean epoch et point des stations slr
        
        Entrée:
        -- fichier SLR  : fichier snx
        
        Sortie: 
        -- tmean : liste dont chaque ligne contient : 
                          [code station,Mean_Epoch(MJD),Point]
        
        """
        #liste pour stocker les informations
        tmean=[]   
        #liste comprenant le bloc Epoch de la classe Laser
        liste1=self.bloc_epoch_slr
        
        #on parcourt la liste pour recuperer seulement les codes,mean epoch et point de chaque station
        for j in range(len(self.liste_stations_slr)):
            for i in range (len(liste1)): 
                if float(self.liste_stations_slr[j])==float(liste1[i][0]):
                    tmean+=[[liste1[i][0],liste1[i][3],liste1[i][4]]]
        return tmean 
        
        
        
                    
    def recup_soln(self):
        """Fonction permettant de selectionner les stations qui correspondent au soln ou on va calculer
        les coordennees references
        
        Entrée:
        -- tmean  : resultat renvoye par tmean_mesure()
        -- liste2 : resultat renvoye par Soln()
        
        Sortie: 
        -- liste_fin : liste dont chaque ligne contient : 
                          [code slr, soln, point]
    
        """
        #liste comportant les stations slr du fichier soln presentes dans tmean
        liste_int=[]
        #liste comportant les informations que l'on souhaite
        liste_fin=[]
        #tmean : [code slr,Mean Epoch, Point]
        tmean=self.matrice_tmean
        #[code slr, Soln, debut acquisition, fin acquisition]
        liste2=self.fichier_soln #liste des codes stations + numero soln correspondant a une periode
        
        #on parcourt les deux listes pour creer une liste comportant les stations en commun  
        if liste2 !=[]:
            for i in range(len(tmean)):
                for j in range(len(liste2)):
                    if float(tmean[i][0])==liste2[j][0]:
                        liste_int+=[[n for n in liste2[j]]]
        #on parcourt tmean et liste_int afin de comparer les dates d'acquisition au soln
        for i in range(len(tmean)):
            presence_station=False  
            if liste2 !=[]:
                for j in range(len(liste_int)):
                    # test pour verifier que la station actuelle est bien repertorie dans le fichier soln
                   if float(tmean[i][0])==liste_int[j][0]:
                       #si c'est le cas on compare les dates d'acquisition et on attribue le bon soln
                       presence_station=True
                       if float(tmean[i][1])<float(liste_int[j][3]) and float(tmean[i][1])>=float(liste_int[j][2]):
                           liste_fin+=[[tmean[i][0],liste_int[j][1],tmean[i][2]]]
                       
            # si ce n'est pas le cas on attribue a la station le Soln 1 
            if presence_station==False:
                liste_fin+=[[tmean[i][0],1,tmean[i][2]]]
        return liste_fin
        
    def info_coord_ref(self):
        """Fonction permettant de renvoyer la matrice comportant les coord ref
        calculées au bon soln 
        
        Entrée:
        -- mat_ref  : matrice renvoyee par Coord_ref()
        -- liste_fin : resultat renvoye par recup_soln()
        
        Sortie: 
        -- mat_result : matrice dont chaque ligne contient : 
                          [code slr, x, y, z, vx, vy, vz, to, point]
                
        """
        #matrice comportant  [code station,STAX,STAY,STAZ,VELX,VELY,VELZ,SOLN, Mean_Epoch(MJD),Point]
        mat_ref=self.coord_ref_slr
        #liste comportant  [code slr, soln, point]      
        liste_fin=self.matrice_soln
        #matrcie ou on stocke les informations 
        mat_result=np.array([[]])
        #on parcourt la matrice et la liste
        for i in np.arange(mat_ref.shape[0]):
            for j in range(len(liste_fin)):
                # test comparant les codes des stations slr
                if float(mat_ref[i][0])==float(liste_fin[j][0]):
                    # test pour comparer les soln 
                    if float(mat_ref[i][7])==float(liste_fin[j][1]):
                        # stockage des informations                                                                             
                        liste_temp=np.array([mat_ref[i]])                                 
                        if mat_result.shape == (1,0):
                            mat_result = liste_temp
                        else:
                            mat_result = np.concatenate((mat_result, liste_temp))
        return mat_result
        
        
    def coord_date(self):
        """Fonction permettant de calculer les coord ref a la bonne date 
        
        Entrée:
        -- mat_result  : matrice renvoyee par info_coord_ref()
        -- tmean : resultat renvoye par tmean_mesure()
        
        Sortie: 
        -- matrice : matrice dont chaque ligne contient : 
                          [code slr, Xt,Yt,Zt]
                
        """
        
        # matrice contenant [code slr, x, y, z, vx, vy, vz, to, point]
        mat_result=self.matrice_info_coord_ref
        
        #matrice contenant [code slr, t, point]
        tmean=self.matrice_tmean

        #matrices ou on stocke les infos
        matrice1=np.array([[]])
        matrice2=np.array([[]])
        
        #on parcourt la matrice t la liste en entrees
        for i in range (mat_result.shape[0]):
            for j in range (len(tmean)):
                if self.path_psd !='':
                    # temps ou on calcule les deformations sismiques
                    time=float(tmean[j][1])
    #                L=seismic(time, self.path_psd).L(time)
                    L = self.L(time, self.bloc_solution_psd)
                #test sur les codes de stations slr
                if float(mat_result[i][0])==float(tmean[j][0]):
                    
                    if mat_result[i][9] == tmean[j][2]:
                    # test si la station a subi une deformations sismique
                        presenceL=False
                        if self.path_psd !='':
                            for k in range(len(L)): 
                                
                                if float(tmean[j][0])==float(L[k][0]):
                                    # si oui on integre dans le calcul des coord le deltal
                                    presenceL=True   
                                    #[deltaLx , deltaLy, deltaLz]
                                    deltal=self.conversion(float(mat_result[i][1]),float(mat_result[i][2]),float(mat_result[i][3]),float(L[k][1]),float(L[k][2]),float(L[k][3]))
                                    if tmean[j][0] == '7237':
                                        print(deltal)
                                        
                                    # Calcul de Xt,Yt,Zt
                                    Xt=float(mat_result[i][1])+float(mat_result[i][4])*((float(tmean[j][1])-float(mat_result[i][8]))/365.25)+float(deltal[0])
                                    Yt=float(mat_result[i][2])+float(mat_result[i][5])*((float(tmean[j][1])-float(mat_result[i][8]))/365.25)+float(deltal[1])
                                    Zt=float(mat_result[i][3])+float(mat_result[i][6])*((float(tmean[j][1])-float(mat_result[i][8]))/365.25)+float(deltal[2])
                                    
                                    # stockage des coord                             
                                    liste_temp=np.array([[float(mat_result[i][0]),float(Xt),float(Yt),float(Zt)]])
        
        #                            print(mat_result[i][0],Xt)
        #                            print(mat_result[i][0],float(mat_result[i][4])*(float(tmean[j][1])-float(mat_result[i][7])),float(deltal[0]))
        #                            print(mat_result[i][0],float(mat_result[i][4]),float(tmean[j][1]),float(mat_result[i][7]))                            
                                    if matrice1.shape == (1,0):
                                        matrice1 = liste_temp
                                    else:
                                        matrice1 = np.concatenate((matrice1,liste_temp))
                                    break
                        # si la station n'a pas subi de deformations sismiques on fait le calcul sans le deltal
                        if presenceL==False:
                            if tmean[j][0]=='1890':
                                print('coord',float(mat_result[i][1]))
                                print('vx',float(mat_result[i][4]) )
                                print('terme vitesse', float(mat_result[i][4])*((float(tmean[j][1])-float(mat_result[i][8]))/365.25))
                                print('tmean',float(tmean[j][1]) )
                                print('tmesure', float(mat_result[i][8]))

                            # Calcul de Xt,Yt,Zt                          
                            Xt=float(mat_result[i][1])+float(mat_result[i][4])*((float(tmean[j][1])-float(mat_result[i][8]))/365.25)
                            Yt=float(mat_result[i][2])+float(mat_result[i][5])*((float(tmean[j][1])-float(mat_result[i][8]))/365.25)
                            Zt=float(mat_result[i][3])+float(mat_result[i][6])*((float(tmean[j][1])-float(mat_result[i][8]))/365.25)
                            
                            #stockage des coord                        
                            liste_temp=np.array([[float(mat_result[i][0]),float(Xt),float(Yt),float(Zt)]])
                            if matrice2.shape == (1,0):
                                matrice2 = liste_temp
                            else:
                                matrice2 = np.concatenate((matrice2,liste_temp))
#        print(matrice1.shape, matrice2.shape)
#        print(matrice1)
        # concatenation des deux matrices
        if matrice1.shape == (1,0):
            matrice = matrice2
        elif matrice2.shape == (1,0):
            matrice = matrice1
        else:
            matrice= np.concatenate((matrice1,matrice2))
        return matrice
        
                      
                   


               
        
    def conversion(self,X,Y,Z,le,ln,lh):
        """Fonction permettant de convertir les deformations post sismiques en coord geographiques
        en coord cartesiennes 
        
        Entree :
        -- X,Y,Z : coord ref des stations slr 
        -- le,ln,lh : deformations post sismiques en coord geographiques
        
        Sortie :
        -- resultat : vecteur avec les deformations post sismiques en coord cartesiennes
        """
        mat=np.array([[le],[ln],[lh]])
        
        #conversion des coordonnées de référence de coordonnées géographique en coordonnées cartesiennes
        conversion=C().cart_to_geo(X,Y,Z)
        
        #longitude de la station slr
        lon=conversion[0]
#        print('test', X, lon)
        
        #latitude de la station slr
        lat=conversion[1]
#        print('test2' , lat)
        
        #matrice de rotation
        R=np.array([[-np.sin(lon)           ,np.cos(lon)            , 0         ],
                    [-np.sin(lat)*np.cos(lon),-np.sin(lat)*np.sin(lon), np.cos(lat)],
                    [np.cos(lat)*np.cos(lon) , np.cos(lat)*np.sin(lon), np.sin(lat)]])
        resultat=np.dot(np.transpose(R),mat)
#        print('L', resultat)
        return resultat

    
    def tri_coord_ref(self, liste_slr, mat_desordre):
        """Permet de réorganiser les coordonnées de référence calculées
        
        Entrée
        -- liste_slr : liste des stations slr co-localisées
        -- mat_desordre : matrice comportant les coordonnées de référence des stations slr avec leurs codes
                          chaque ligne contient : [code_slr, x_ref, y_ref, z_ref]
        Sortie:
        -- vecteur_tri : vecteur contenant les coordonnées de référence en colonne avec le code
                         le code associé des stations slr. Les stations slr sont triées de manière
                         a pouvoir effectuer les calculsde moindre carrées. Le vecteur se présente
                         comme suit:
                         [[code_slr1, x_ref1],
                          [code_slr1, y_ref1],
                          [code_slr1, z_ref1],
                          ...
                          [code_slrn, z_refn]]
                          dim(vecteur_tri) = (3*nombre_stations, 2)
        """
        vecteur_tri = np.array([[]])
        
        #on trie les données
        for i in range(len(liste_slr)):
            for j in range( mat_desordre.shape[0]):
                if mat_desordre[j][0] == liste_slr[i]:
                    liste_temp = np.array([[mat_desordre[j][0], mat_desordre[j][1]], 
                                           [mat_desordre[j][0],mat_desordre[j][2]], 
                                            [mat_desordre[j][0],mat_desordre[j][3]]])
                    if vecteur_tri.shape == (1,0):
                        vecteur_tri = liste_temp
                    else:
                        vecteur_tri = np.concatenate((vecteur_tri, liste_temp))
                    break

        return vecteur_tri
        
        
    def lecture_solution_psd(self, chemin_psd):
        """Fonction permettant de lire le bloc "SOLUTION/ESTIMATE" du fichier des déformations 
        post-seismique.
        
        parametres
        --chemin_psd = chemin du fichier contenant les déformations seismique
        
        sortie
        -- liste : liste des données contenus dans le bloc

        """
        try:
            fichier=open(chemin_psd,'r')
            lignes=fichier.readlines()
            i=0
            liste=[]
            for ligne in lignes:
                ligne_test=ligne.split()
                
                if ligne_test[0] =='+SOLUTION/ESTIMATE':
                    j=i+2
                    while ((lignes[j]).split())[0]!='-SOLUTION/ESTIMATE':
                                            
                        type_data = (lignes[j])[7:13]
                        
                        code = (lignes[j])[14:18]
    #                    print('test'+str(code))
                        epoch = (lignes[j])[27:39]
                        estimate_sol = float((lignes[j])[47:69])
                        liste+=[[type_data, code, epoch,estimate_sol]]
                        j+=1
                    break
                i+=1
            return liste
        except:
            return ''
        
    def L(self, t, bloc_sol_psd):
        """Permet de calculer la somme totale des corrections des déformations post-seismiques
        exprimées dans le repère locale à un temp t.
        
        Entrée
        -- t : temps moyen de la periode des mesures(format MJD)
        -- bloc_sol_psd : matrice contenant les informations du bloc EPOCH  du fichier psd
        
        Sortie : 
        -- L : matrice contenant les déformations post-seimique avec leurs codes slr associées 
        """
        liste = bloc_sol_psd
        
        #listes temporaires permettant de sotcker les différentes informations concernant 
        #le calcul des déformations post-seismiques
        a_exp_e, ti_exp_e, time_exp_e, a_log_e, ti_log_e, time_log_e = [], [], [], [], [], []
        a_exp_n, ti_exp_n, time_exp_n, a_log_n, ti_log_n, time_log_n = [], [], [], [], [], []
        a_exp_h, ti_exp_h, time_exp_h, a_log_h, ti_log_h, time_log_h = [], [], [], [], [], []

        station_temp = ''
        mat_station = np.zeros((3,5))
        liste_station_matrice = []
        k=0
        resultat =[]
        while k != len(liste)-1:
            if station_temp == '':
                station_temp = liste[k][1]
            if liste[k][1]==station_temp:
#                print(liste[i][1]+' ' +liste[i][0]+' ' + str(conv.convert_utc_mjd(liste[i][2])))
                if liste[k][0]=='AEXP_E':

                    a_exp_e +=[liste[k][3]]
                    time_exp_e +=[conv.convert_utc_mjd(liste[k][2])]
                elif liste[k][0]=='ALOG_E':

                    a_log_e +=[liste[k][3]]
                    time_log_e +=[conv.convert_utc_mjd(liste[k][2])]
                elif liste[k][0]=='TEXP_E':

                    ti_exp_e += [liste[k][3]]
                elif liste[k][0]=='TLOG_E':

                    ti_log_e += [liste[k][3]]
                elif liste[k][0]=='AEXP_N':

                    a_exp_n +=[liste[k][3]]
                    time_exp_n +=[conv.convert_utc_mjd(liste[k][2])]
                elif liste[k][0]=='ALOG_N':

                    a_log_n +=[liste[k][3]]
                    time_log_n +=[conv.convert_utc_mjd(liste[k][2])]
                elif liste[k][0]=='TEXP_N':

                    ti_exp_n += [liste[k][3]]
                elif liste[k][0]=='TLOG_N':

                    ti_log_n += [liste[k][3]]
                elif liste[k][0]=='AEXP_H':

                    a_exp_h +=[liste[k][3]]
                    time_exp_h +=[conv.convert_utc_mjd(liste[k][2])]
                elif liste[k][0]=='ALOG_H':

                    a_log_h +=[liste[k][3]]
                    time_log_h +=[conv.convert_utc_mjd(liste[k][2])]
                elif liste[k][0]=='TEXP_H':

                    ti_exp_h += [liste[k][3]]
                elif liste[k][0]=='TLOG_H':

                    ti_log_h += [liste[k][3]]
            else:
                liste_station_matrice +=[[liste[k-1][1], mat_station]]
#                if liste[k-1][1] == '7403':
#                    print(a_exp_e, ti_exp_e, a_log_e, ti_log_e, time_exp_e)
#                mat_station = np.zeros((3,5))
                    
                #on calcul les déformations post-seismique en 'Est'
                sum_exp,sum_log=0,0
                if len(a_exp_e) != 0:
                    for i in range(len(a_exp_e)):
                        sum_exp+=a_exp_e[i]*(1-np.exp(-((t-time_exp_e[i])/365.25)/ti_exp_e[i]))
                if len(a_log_e) != 0:                    
                    for j in range(len(a_log_e)):
                        sum_log+=a_log_e[j]*np.log(1+((t-time_log_e[j])/365.25)/ti_log_e[j])
#                if liste[k-1][1] == '7403':
#                    print(sum_exp, sum_log)
                l_e=sum_exp+sum_log
                
                
                #on calcul les déformations post-seismique en 'Nord'
                sum_exp,sum_log=0,0
                if len(a_exp_n) != 0:  
                    for i in range(len(a_exp_n)):
                        sum_exp+=a_exp_n[i]*(1-np.exp(-((t-time_exp_n[i])/365.25)/ti_exp_n[i]))
                if len(a_log_n) != 0:  
#                    print(len(a_log_n), len(ti_log_n), len(time_log_n))
                    for j in range(len(a_log_n)):
                        sum_log+=a_log_n[j]*np.log(1+((t-time_log_n[j])/365.25)/ti_log_n[j])
                l_n=sum_exp+sum_log
                
                #on calcul les déformations post-seismique en 'Altitude h'
                sum_exp,sum_log=0,0
                if len(a_exp_h) != 0:
                    for i in range(len(a_exp_h)):
                        sum_exp+=a_exp_h[i]*(1-np.exp(-((t-time_exp_h[i])/365.25)/ti_exp_h[i]))
                if len(a_log_h) != 0:
                    for j in range(len(a_log_h)):
                        sum_log+=a_log_h[j]*np.log(1+((t-time_log_h[j])/365.25)/ti_log_h[j])
                l_h=sum_exp+sum_log
                
                #on stocke le résultat des calculs
                resultat+= [[liste[k-1][1], l_e, l_n, l_h ]]
                
                #on réinitialise les listes temporaires de stockage des données
                a_exp_e, ti_exp_e, time_exp_e, a_log_e, ti_log_e, time_log_e = [], [], [], [], [], []
                a_exp_n, ti_exp_n, time_exp_n, a_log_n, ti_log_n, time_log_n = [], [], [], [], [], []
                a_exp_h, ti_exp_h, time_exp_h, a_log_h, ti_log_h, time_log_h = [], [], [], [], [], []
                station_temp = liste[k][1]
                k -= 1

            k+=1
        return resultat




                
            
            
            
    
    def convert(self,date) :
        """
        Fonction permettant de convertir une date au format  en 
        parametre: date format 'YY:DD:SS'
        sortie: date format 'YY:DD:HH:M' compatible avec le module astropy
                pour apres la convertir en jour julien modifie
        """
        
        form=date.split(':')
       
        if form[0]<='50' and form[0]>='0':
            year='20'+form[0]
        else:
            year='19'+form[0]
        day=form[1]
        h=int(float(form[2])/3600)
        m=int((float(form[2])/3600-h)*60)
        if m<10:
            m='0'+str(m)
        else:
            m=str(m)
        date_f=year+':'+day+':'+str(h)+':'+m
        return(date_f)
    


if __name__ == '__main__':
    s=SLR('simulations_test/coord_ref_slr.txt','simulations_test/soln_slr.txt','simulations_test/psd_slr.txt', ['7403', '1890' ], Laser('simulations_test/ilrsb.pos+eop.170507.v135.snx').bloc_epoch)
#    result=s.Soln()
    #result1=s.coord_date()
#    print(result)
    #print(result1)

#    coord_ref = s.coord_ref_slr
#    time = 57877.5
#    L=seismic(time).L(time)
    
    test_ref = s.coord_ref_slr
    test=s.coord_sans_trie
#    test_trie = s.coord_avec_trie
