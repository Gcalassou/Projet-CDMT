# -*- coding: utf-8 -*-
"""
Created on Wed Mar 15 10:21:16 2017

@author: Gabriel
"""
#test = Ftp('itrf.ign.fr',['incoming'])

#test.connexion_changeDir_download('codomes_gps.snx')
#import Ftp as ftp
#import numpy as np
#import os
#from FtpBis import Ftp('itrf.ign.fr',['incoming']) as test
class DOMES:
    def __init__(self,type_data,number, path):
        self.type_data=type_data
        self.number=number
        self.path= path
        self.lecture_fichier = self.lecture_data()
        
    def lecture_data(self):
#        if os.path.exists(self.path) == False:
#            mon_ftp=ftp.Ftp('itrf.ign.fr',['incoming'],'','')
#            mon_ftp.connexion_changeDir_download(self.path,'')
#        else:
#            print('fichier existant')
#        mat = np.genfromtxt(self.path)
        fichier = open(self.path, 'r')
        lignes = fichier.readlines()
        code, domes=[],[]
        for ligne in lignes:
            ligne= ligne.split()
            code += [ligne[0]]
            domes+= [ligne[2]]
        return code, domes
        
    def conversion(self):
        mat=self.lecture_fichier
        liste_laser=[]
        if self.type_data=="GPS":
            i=0
            for value in mat[0]:
                
                if value[:5] == self.number:
                    return mat[1][i]
                    break
                i+=1
        if self.type_data=="Laser":
            i=0
            for value in mat[1]:
                
                if value[:5] == self.number:
                    liste_laser += [mat[0][i]]
#                    break
                i+=1
            return liste_laser
            
if __name__ == '__main__':
    test = DOMES("GPS", "8834", 'simulations_test\\codomes_coord.snx')
    print(test.conversion())
    test2= DOMES("Laser", test.conversion()[:5], 'simulations_test\\codomes_coord.snx')
    mat_Domes= test.lecture_data()
#    print(mat_Domes[:,0])
#    print(test.conversion())
    print(test2.conversion())
                