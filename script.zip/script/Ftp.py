# -*- coding: utf-8 -*-
"""
Created on Wed Mar  8 14:46:21 2017

@author: dpts
"""


"""
ce script fonctionne
"""

import ftplib as ftp
import os
import epoch
import shutil


class Ftp :
    
    def __init__(self,address,listDir,user,password):
        """
        address : adresse du ftp, chaine de carac, forme 'cddis.nasa.gov'
        listDir : liste contenant les répertoires successifs dans le bon ordre
        user : chaine de caractères, nom d'utilisateur du ftp, si ftp sans user alors user=''
        password : chaine de caractères, mot de passe du ftp, si ftp sans mdp password = ''
        """
        self.address = address
        self.listDir = listDir
        self.user = user
        self.password = password
        

    def connexion(self):
        """
        permet de se connecter au ftp 
        """        
        
        connex = ftp.FTP(self.address)
        if len(self.user)==0 and len(self.password)==0 :
            connex.login()
        else : 
            connex.login(self.user,self.password)
        connex.dir()
            
    
        
        
    def connexion_changeDir_download(self,ftpfile,destination):
        """
        ftpfile : chaine de caractère, nom du fichier à télécharger
        destination : chaine de caractère, chemin du répertoire où on va enregristrer le fichier
        connexion au ftp, changement de répertoire puis téléchargement du fichier ftpfile
        """
        #connexion au ftp
        connex = ftp.FTP(self.address)
        if len(self.user)==0 and len(self.password)==0 :
            connex.login()
        else :
            connex.login(self.user,self.password)
        #changement de répertoire
        n = len(self.listDir)
        
        for i in range(0,n):
            connex.cwd(self.listDir[i])
            

        #si l'utilisateur ne renseigne pas la destination,
        #on enregistre dans le répertoire courant
        if len(destination)==0 :  
            connex.retrbinary('RETR '+ftpfile, open(ftpfile,'wb').write)  #transfert de fichiers en binaire
            #connex.retrlines('RETR '+ftpfile, open(ftpfile,'wb').write) #transfert de fichiers en ascii mode
        else:
            
            connex.retrbinary('RETR '+ftpfile, open(os.path.join(destination,ftpfile),'wb').write)
    
    def connexion_download_sinex(self,destination,station):
        """Permet de télécharger les fichiers sinex correspondants au fichiers gps traité
        parametres
        --destination : chemin du fichier à aller chercher
        --station : code de la station gps étudiée
        """
        connex = ftp.FTP(self.address)
        if len(self.user)==0 and len(self.password)==0 :
            connex.login()
        else :
            connex.login(self.user,self.password)
        #changement de répertoire
        n = len(self.listDir)
        
        for i in range(0,n):
            connex.cwd(self.listDir[i])
            
            
        liste_fichier = connex.nlst()
        detruire, liste_ok = [], []
        i=0
#        print(liste_fichier)
#        test1, i = self.test_epoch(liste_fichier, station, 0)
        while i <len(liste_fichier):
#        for i in range(len(liste_fichier)):
            #on passe en revu l'ensemble des fichiers présents dans le dossier consulté
#            print(liste_fichier[i])
            test1, test2=0,0
            
            test=0
            test1=0
            while test == 0:
                if len(destination)==0 :
                    print('test : '+str(liste_fichier[i]))
                    connex.retrbinary('RETR '+liste_fichier[i], open(liste_fichier[i],'wb').write)  #transfert de fichiers en binaire
                #connex.retrlines('RETR '+ftpfile, open(ftpfile,'wb').write) #transfert de fichiers en ascii mode
                else:
                    
                    connex.retrbinary('RETR '+liste_fichier[i], open(os.path.join(destination,liste_fichier[i]),'wb').write)
            
#            try:
                for j in range(len(epoch.lecture_EPOCH(liste_fichier[i]))):
    #                    print(j)
                    if epoch.lecture_EPOCH(liste_fichier[i])[j][0]==station:
                        print("ok: "+str(liste_fichier[i]))
                        
                        test1=j
#                print("fichier accepté : "+str(liste_fichier[i]))
                        test=1
                        liste_ok+=[liste_fichier[i]]
                        break
                if test == 0:
#                    liste_fichier[i].close()
#                    os.remove(liste_fichier[i])
                    detruire+=[liste_fichier[i]]
                i+=1
           
            if i>0:
#                for j in range(len(epoch.lecture_EPOCH(liste_fichier[i]))):
##                    try:
#                        
#                    if epoch.lecture_EPOCH(liste_fichier[i])[j][0]==station:
#                        test1=j
#                test2, w = self.test_epoch(liste_fichier, station, i)
#                try:
#                    for k in range(len(epoch.lecture_EPOCH(liste_fichier[i-1]))):
#                        if epoch.lecture_EPOCH(liste_fichier[i])[k][0]==station:
#                            test2=k
                    
#                print(epoch.lecture_EPOCH(liste_fichier[0])[test1][3])   
#                print(epoch.lecture_EPOCH(liste_fichier[i])[test2][3])
#                print(epoch.lecture_EPOCH(liste_fichier[0])[test1][3]-epoch.lecture_EPOCH(liste_fichier[i])[test2][3])
#                except:
#                    print('fichier non trouvé')
#                i=w
                if test==1:
#                    print('test ok')
#                    print(epoch.lecture_EPOCH(liste_fichier[i-1])[test2][3]-epoch.lecture_EPOCH(liste_fichier[0])[test1][3]>7)
                    if epoch.lecture_EPOCH(liste_fichier[i-1])[test2][3]-epoch.lecture_EPOCH(liste_fichier[0])[test1][3]>7 and i!=0:
                        print('sortie de la boucle')
                        print(epoch.lecture_EPOCH(liste_fichier[i-1])[test2][3])
                        liste_ok.remove(liste_fichier[i-1])
                        detruire+=[liste_fichier[i-1]]
                        break
       
            print(i)
        time = epoch.lecture_EPOCH(liste_fichier[0])[test1][3] 
        for t in detruire:
            inputFile = open((t), "rb")
            inputFile.close()
            os.remove(t)
        print(liste_ok, time)
        return liste_ok, time
#            shutil.rmtree(os.getcwd()+'\\'+t,ignore_errors=True)
                        
    
    def test_epoch(self, liste_fichier, station, i):
        test=0
        test1=0
        while test == 0:
            
#            try:
            for j in range(len(epoch.lecture_EPOCH(liste_fichier[i]))):
#                    print(j)
                if epoch.lecture_EPOCH(liste_fichier[i])[j][0]==station:
                    print("ok: "+str(liste_fichier[i]))
                    test1=j
#                print("fichier accepté : "+str(liste_fichier[i]))
            test=1
            i+=1
#            except:
#                print("fichier refusé : "+str(liste_fichier[i]))
#                i=i+1
#                print("fichier test : "+str(liste_fichier[i]))
#                self.test_epoch(liste_fichier, station, i)
        return test1, i
     
    def connexion_changeDir_upload(self,diskfile,path):
        """
        connexion au ftp
        changement de répertoire
        poste le fichier diskfile sur le ftp
        diskfile (chaine de caractères) est le nom du fichier à uploader
        path (chaine de caractères) : répertoire du fichier
        """
        #connexion au ftp
        connex = ftp.FTP(self.address)
        if len(self.user)==0 and len(self.password)==0 :
            connex.login()
        else :
            connex.login(self.user,self.password)
        #changement de répertoire
        n = len(self.listDir)
        fichier = path+'/'+diskfile
        file = open(fichier,'rb')
        
        for i in range(0,n):
            connex.cwd(self.listDir[i])
        connex.storbinary('STOR ' + diskfile,file)
        
        file.close()
         
      
      
      
      
      
    
        
#essai pour récupérer un fichier -> cela fonctionne
#test = Ftp('itrf.ign.fr',['incoming'],'','')
#
#test.connexion_changeDir_download('codomes_gps.snx')



#essai pour poster un fichier -> cela fonctionne
#test1 = Ftp('ftp2.ign.fr',[],'ing2-geocentre','Eiguceuqu0Yiu8wa')
#test1.connexion_changeDir_upload('nomTresTresSerieux','/home/dpts/Bureau/ProjetDev')

#connec = Ftp('cddis.gsfc.nasa.gov',['reports','slrlog'],'','')
#test = Ftp('ftp2.ign.fr',['simulations','annuel_avec_bruit'],'ing2-geocentre','Eiguceuqu0Yiu8wa' )
#test.connexion_changeDir_download('BADG_igs_IGS.res','C:\\Users\\Gabriel\\Documents\\Cours ENSG\\2eme annee\\Projet_dev')
#test.connexion_changeDir_download('SNXOUT1004.SNX','')
#test.connexion_download_sinex('', '1889')
#test2 = Ftp('ftp2.ign.fr',[''],'ing2-geocentre','Eiguceuqu0Yiu8wa' )
#test2.connexion_changeDir_download('simulations','')
#fichier = open('log_names.txt','r')

#construction d'une liste de noms de fichiers pour en télécharger plusieurs à la fois
#liste = fichier.readlines()



##formatage des données
#for i in range(len(liste)) :
#    liste[i] = liste[i].rstrip('\n')  #suppression des \n
#    liste[i] = liste[i].rstrip('\t')  #suppression des \t
#
##connec.connexion_changeDir_download('ajaf_20080929.log','/home/dpts/Bureau/ProjetDev/Logs')
#
#for i in range(0,len(liste)):
#    print(i)
#    ftpfile = (liste[i])
#    connec.connexion_changeDir_download(ftpfile,'/home/dpts/Bureau/ProjetDev/Logs')
#    
#ftpfile = liste[1]
#print(ftpfile)
#connec.connexion_changeDir_download(ftpfile)



#gestion de l'erreur 550
#
#except ftplib.error_perm, resp:
#    if str(resp) == "550 No files found":
#        print "No files in this directory"
#    else:
#        raise
