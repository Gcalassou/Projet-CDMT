# -*- coding: utf-8 -*-
"""
Created on Tue May  2 21:10:36 2017

@author: Oumaïma
"""

"""Ce script permet de calculer les coordonnées réf à la bonne date. 
 


Entrée:
-- chemin fichier psd SLR : chemin du fichier contenant les différentes infos postsimiques touchant certaines stations SLR
-- chemin fichier Soln SLR : chemin du fichier contenant les numéros Soln des stations SLR
-- chemin fichier coord ref SLR : chemin du fichier contenant les coord ref SLR 
-- bloc EPOCH du fichier snx : matrice contenant les informations nous intéressant du bloc "SOLUTION/EPOCHS"

Sortie:
--

"""

from astropy.time import Time
from lecture_fichier_snx import Laser
import numpy as np
import math as m 
from post_seismic import seismic 
from convert import Converter as C
class SLR:
    
    def __init__(self,path_coor_ref_slr,path_soln,path_psd, liste_stations_slr, bloc_epoch_slr):
        self.path_ref=path_coor_ref_slr#'simulations_test/ITRF2014-ILRS-TRF.SNX'
        self.path_soln=path_soln
        self.path_psd=path_psd
        self.liste_stations_slr = liste_stations_slr
        self.bloc_epoch_slr = bloc_epoch_slr
        self.fichier_soln=self.Soln()
        self.coord_ref_slr=self.Coord_ref()[0]
        self.e1=self.tmean_mesure()
        self.e2=self.recup_soln()
        self.e3=self.info_coord_ref()
        self.coord_sans_trie = self.coord_date()
        self.coord_avec_trie = self.tri_coord_ref(self.liste_stations_slr, self.coord_sans_trie)
    


        
    
    
    def Soln(self):
        """
        Fonction permettant de lire le bloc EPOCHS d'un fichier SLR
        
        Entrée:
        -- fichier soln slr : fichier snx
        
        Sortie: 
        -- mat_resultat : matrice dont chaque ligne contient : 
                          [code station,SOLN,date de début d'acquisition {MJD}, 
                          date de fin d'acquisition{MJD} ]
        """
        #lecture du fichier snx
        fichier=open(self.path_soln,'r')
        lignes=fichier.readlines()
        
        #indice de la ligne du fichier
        i=0
        
        #liste contenant les lignes du fichier qui nous interessent (celles avec P)
        liste=[]
        
        #matrice contenant les infos souhaitees
        mat_resultat=np.array([[]])
        
        #on parcourt les lignes jusqu'à trouver le bloc 'SOLUTION/DISCONTINUITY'
        for ligne in lignes:
            ligne=ligne.split()
            if ligne[0]=='+SOLUTION/DISCONTINUITY':
                #indice des lignes au sein du bloc qui nous interesse 
                j=i+1
                #on parcourt le bloc qui nous interesse pour y stocker les informations qui nous interessent
                while ((lignes[j]).split())[0]!='-SOLUTION/DISCONTINUITY':
                    ligne_t=lignes[j].split()
                    #test pour garder les lignes du bloc contenant 'P'
                    if ligne_t[6]=='P':
                        liste+=[((lignes[j]).split())[0:7]]
          
                    j+=1
            i+=1
        #on parcourt notre liste pour y extraire les informations cherchées
        for i in range(len(liste)):
            #code station slr
            code=liste[i][0]
            #soln station slr
            soln=liste[i][2]
                
               
            if liste[i][4]=='00:000:00000':
                #les dates de début de la période SOLN à -infini sont ramenees a 0
                t_init=0
                
                t_fin=self.convert(liste[i][5])
                t_f=Time(t_fin)
                t_f.format='mjd'
                #on stocke dans cette liste les codes,soln,t_i,t_f pour chaque station
                liste_temp=np.array([[int(code),int(soln),t_init,float(t_f.value)]])
            
            elif liste[i][5]=='00:000:00000' :
                #les dates de fin periode SOLN convertis en MJD    
                t_init=self.convert(liste[i][4])
                t_i=Time(t_init)
                t_i.format='mjd'
                #les dates de  fin de période SOLN à + infini sont ramenees a 1000000
                t_fin=1000000
                #on stocke dans cette liste les codes,soln,t_i,t_f pour chaque station
                liste_temp=np.array([[int(code),int(soln),float(t_i.value),t_fin]])
                
            # le cas ou les dates de periode soln ne sont pas infinies  
            else:
               # les dates de periode sont convertis aussi en MJD
               t_i=self.convert(liste[i][4])
               t_init=Time(t_i)
               t_init.format='mjd'
               t_f=self.convert(liste[i][5])
               t_fin=Time(t_f)
               t_fin.format='mjd'
               #on stocke dans cette liste les codes,soln,t_i,t_f pour chaque station
               liste_temp=np.array([[int(code),int(soln),float(t_init.value),float(t_fin.value)]])
            if mat_resultat.shape == (1,0):
               mat_resultat = liste_temp
            else:
               mat_resultat = np.concatenate((mat_resultat, liste_temp))

                
        return(mat_resultat)
    
    
    
    
        
    
     
    def Coord_ref(self):
        """
        Fonction permettant de lire le bloc EPOCHS d'un fichier SLR
        
        Entrée:
        -- fichier coord ref SLR : fichier snx
        
        Sortie: 
        -- mat_resultat : matrice dont chaque ligne contient : 
                          [code station,STAX,STAY,STAZ,VELX,VELY,VELZ,
                          SOLN, Mean_Epoch(MJD),Point]
        """
    
        #lecture du fichier snx
        fichier=open(self.path_ref,'r')
        lignes=fichier.readlines()
        
        #indice de la ligne du fichier
        i=0
        
        #matrice conteant les infos souhaitees
        mat_resultat=np.array([[]])
        
        #on parcourt les lignes jusqu'à trouver le bloc 'SOLUTION/ESTIMATE'
        for ligne in lignes:
            ligne=ligne.split()
            
            if ligne[0] =='+SOLUTION/ESTIMATE':
                #indice de la ligne du bloc parcourut 
                j=i+2
#                x=i+2
#                taille_bloc=0
#                while ((lignes[x]).split())[0]!='-SOLUTION/ESTIMATE':
#                    taille_bloc+=1
#                    x+=1
                #on parcourt le bloc qui nous interesse pour y stocker les informations qui nous interessent    
                while ((lignes[j]).split())[0]!='-SOLUTION/ESTIMATE':
                    ligne_test=lignes[j].split()
                    #code station slr
                    code=ligne_test[2]
#                    compteur=0
#                    t=j
#                    #print(((lignes[j]).split())[2])
#                    #print(len(lignes))
#                    print(j)
#                    while ((lignes[t]).split())[2]==((lignes[j]).split())[2] and t<taille_bloc :
                        #print(((lignes[t]).split())[0])
#                        compteur+=1
#                        t+=1
                        #print(t,j)
                        #print(t)
                        #print(((lignes[t]).split())[2]==((lignes[j]).split())[2])
#                    nb_point=compteur//6
#                    print(compteur)
#                    for k in range(nb_point):
                        
                    #X,Y,X de la station slr
                    STAX=float((lignes[j].split())[8])
                    STAY=float((lignes[j+1].split())[8])
                    STAZ=float((lignes[j+2].split())[8])
                    
                    #vx,vy,vz de la station slr
                    VELX=float((lignes[j+3].split())[8])
                    VELY=float((lignes[j+4].split())[8])
                    VELZ=float((lignes[j+5].split())[8])
                    
                    #SOLN de la station slr
                    SOLN=ligne_test[4]
                    
                    #REF_EPOCH convertit en MJD 
                    EPOCH=self.convert(ligne_test[5])  
                    ref_epoch=Time(EPOCH)
                    ref_epoch.format='mjd'
                    
                    #PT de la station slr
                    Point=ligne_test[3]
                    
                    #stockage des informations 
                    liste_temp=np.array([[int(code),STAX,STAY,STAZ,float(VELX),float(VELY),float(VELZ),float(SOLN),float(ref_epoch.value),Point]])
                    if mat_resultat.shape == (1,0):
                        mat_resultat = liste_temp
                    else:
                        mat_resultat = np.concatenate((mat_resultat, liste_temp))
                    
                
                    j+=6
                
                break
            i+=1
        return mat_resultat,j-(i+2)
    
    
    def tmean_mesure(self):
        """Fonction permettant de recuperer les codes,mean epoch et point des stations slr
        
        Entrée:
        -- fichier SLR  : fichier snx
        
        Sortie: 
        -- tmean : liste dont chaque ligne contient : 
                          [code station,Mean_Epoch(MJD),Point]
        
        """
        #liste pour stocker les informations
        tmean=[]   
        #liste comprenant le bloc Epoch de la classe Laser
        liste1=self.bloc_epoch_slr
        #on parcourt la liste pour recuperer seulement les codes,mean epoch et point de chaque station
        for j in range(len(self.liste_stations_slr)):
            for i in range (len(liste1)): 
                if float(self.liste_stations_slr[j])==float(liste1[i][0]):
                    tmean+=[[liste1[i][0],liste1[i][3],liste1[i][4]]]
        return tmean 
        
        
        
                    
    def recup_soln(self):
        """Fonction permettant de selectionner les stations qui correspondent au soln ou on va calculer
        les coordennees references
        
        Entrée:
        -- tmean  : resultat renvoye par tmean_mesure()
        -- liste2 : resultat renvoye par Soln()
        
        Sortie: 
        -- liste_fin : liste dont chaque ligne contient : 
                          [code slr, soln, point]
    
        """
        #liste comportant les stations slr du fichier soln presentes dans tmean
        liste_int=[]
        #liste comportant les informations que l'on souhaite
        liste_fin=[]
        #tmean : [code slr,Mean Epoch, Point]
        tmean=self.e1
        #[code slr, Soln, debut acquisition, fin acquisition]
        liste2=self.fichier_soln #liste des codes stations + numero soln correspondant a une periode
        
        #on parcourt les deux listes pour creer une liste comportant les stations en commun        
        for i in range(len(tmean)):
            for j in range(len(liste2)):
                if float(tmean[i][0])==liste2[j][0]:
                    liste_int+=[[n for n in liste2[j]]]
        
        #on parcourt tmean et liste_int afin de comparer les dates d'acquisition au soln
        for i in range(len(tmean)):
            presence_station=False           
            for j in range(len(liste_int)):
                # test pour verifier que la station actuelle est bien repertorie dans le fichier soln
               if float(tmean[i][0])==liste_int[j][0]:
                   #si c'est le cas on compare les dates d'acquisition et on attribue le bon soln
                   presence_station=True
                   if float(tmean[i][1])<float(liste_int[j][3]) and float(tmean[i][1])>=float(liste_int[j][2]):
                       liste_fin+=[[tmean[i][0],liste_int[j][1],tmean[i][2]]]
                       
            # si ce n'est pas le cas on attribue a la station le Soln 1 
            if presence_station==False:
                liste_fin+=[[tmean[i][0],1,tmean[i][2]]]
        return liste_fin
        
    def info_coord_ref(self):
        """Fonction permettant de renvoyer la matrice comportant les coord ref
        calculées au bon soln 
        
        Entrée:
        -- mat_ref  : matrice renvoyee par Coord_ref()
        -- liste_fin : resultat renvoye par recup_soln()
        
        Sortie: 
        -- mat_result : matrice dont chaque ligne contient : 
                          [code slr, x, y, z, vx, vy, vz, to, point]
                
        """
        #matrice comportant  [code station,STAX,STAY,STAZ,VELX,VELY,VELZ,SOLN, Mean_Epoch(MJD),Point]
        mat_ref=self.coord_ref_slr
        #liste comportant  [code slr, soln, point]      
        liste_fin=self.e2
        #matrcie ou on stocke les informations 
        mat_result=np.array([[]])
        #on parcourt la matrice et la liste
        for i in np.arange(mat_ref.shape[0]):
            for j in range(len(liste_fin)):
                # test comparant les codes des stations slr
                if float(mat_ref[i][0])==float(liste_fin[j][0]):
                    # test pour comparer les soln 
                    if float(mat_ref[i][7])==float(liste_fin[j][1]):
                        # stockage des informations                                                                             
                        liste_temp=np.array([mat_ref[i]])                                 
                        if mat_result.shape == (1,0):
                            mat_result = liste_temp
                        else:
                            mat_result = np.concatenate((mat_result, liste_temp))
        return mat_result
        
        
    def coord_date(self):
        """Fonction permettant de calculer les coord ref a la bonne date 
        
        Entrée:
        -- mat_result  : matrice renvoyee par info_coord_ref()
        -- tmean : resultat renvoye par tmean_mesure()
        
        Sortie: 
        -- matrice : matrice dont chaque ligne contient : 
                          [code slr, Xt,Yt,Zt]
                
        """
        
        # matrice contenant [code slr, x, y, z, vx, vy, vz, to, point]
        mat_result=self.e3
        
        #matrice contenant [code slr, t, point]
        tmean=self.e1

        #matrices ou on stocke les infos
        matrice1=np.array([[]])
        matrice2=np.array([[]])
        
        #on parcourt la matrice t la liste en entrees
        for i in range (mat_result.shape[0]):
            for j in range (len(tmean)):
                # temps ou on calcule les deformations sismiques
                time=float(tmean[j][1])
                L=seismic(time).L(time)
                
                #test sur les codes de stations slr
                if float(mat_result[i][0])==float(tmean[j][0]):
                    
                    if mat_result[i][9] == tmean[j][2]:
                    # test si la station a subi une deformations sismique
                        presenceL=False
                        for k in range(len(L)): 
                            
                            if float(tmean[j][0])==float(L[k][0]):
                                # si oui on integre dans le calcul des coord le deltal
                                presenceL=True   
                                #[deltaLx , deltaLy, deltaLz]
                                deltal=self.conversion(float(mat_result[i][1]),float(mat_result[i][2]),float(mat_result[i][3]),float(L[k][1]),float(L[k][2]),float(L[k][3]))
                                
                                # Calcul de Xt,Yt,Zt
                                Xt=float(mat_result[i][1])+float(mat_result[i][4])*(float(tmean[j][1])-float(mat_result[i][8]))+float(deltal[0])
                                Yt=float(mat_result[i][2])+float(mat_result[i][5])*(float(tmean[j][1])-float(mat_result[i][8]))+float(deltal[1])
                                Zt=float(mat_result[i][3])+float(mat_result[i][6])*(float(tmean[j][1])-float(mat_result[i][8]))+float(deltal[2])
                                
                                # stockage des coord                             
                                liste_temp=np.array([[float(mat_result[i][0]),float(Xt),float(Yt),float(Zt)]])
    
    #                            print(mat_result[i][0],Xt)
    #                            print(mat_result[i][0],float(mat_result[i][4])*(float(tmean[j][1])-float(mat_result[i][7])),float(deltal[0]))
    #                            print(mat_result[i][0],float(mat_result[i][4]),float(tmean[j][1]),float(mat_result[i][7]))                            
                                if matrice1.shape == (1,0):
                                    matrice1 = liste_temp
                                else:
                                    matrice1 = np.concatenate((matrice1,liste_temp))
                                break
                        # si la station n'a pas subi de deformations sismiques on fait le calcul sans le deltal
                        if presenceL==False:
                            
                            # Calcul de Xt,Yt,Zt                          
                            Xt=float(mat_result[i][1])+float(mat_result[i][4])*(float(tmean[j][1])-float(mat_result[i][8]))
                            Yt=float(mat_result[i][2])+float(mat_result[i][5])*(float(tmean[j][1])-float(mat_result[i][8]))
                            Zt=float(mat_result[i][3])+float(mat_result[i][6])*(float(tmean[j][1])-float(mat_result[i][8]))
                            
                            #stockage des coord                        
                            liste_temp=np.array([[float(mat_result[i][0]),float(Xt),float(Yt),float(Zt)]])
                            if matrice2.shape == (1,0):
                                matrice2 = liste_temp
                            else:
                                matrice2 = np.concatenate((matrice2,liste_temp))
#        print(matrice1.shape, matrice2.shape)
#        print(matrice1)
        # concatenation des deux matrices
        matrice= np.concatenate((matrice1,matrice2))
        return matrice
        
                      
                   


               
        
    def conversion(self,X,Y,Z,le,ln,lh):
        """Fonction permettant de convertir les deformations post sismiques en coord geographiques
        en coord cartesiennes 
        
        Entree :
        -- X,Y,Z : coord ref des stations slr 
        -- le,ln,lh : deformations post sismiques en coord geographiques
        
        Sortie :
        -- resultat : vecteur avec les deformations post sismiques en coord cartesiennes
        """
        mat=np.array([[le],[ln],[lh]])
        conversion=C().cart_to_geo(X,Y,Z)
        lon=conversion[0]
        lat=conversion[1]
        R=np.array([[-m.sin(lon),m.cos(lon),0],[-m.sin(lat)*m.cos(lon),-m.sin(lat)*m.sin(lon),m.cos(lat)],[m.cos(lat)*m.cos(lat),m.cos(lat)*m.sin(lon),m.sin(lat)]])
        resultat=np.dot(np.transpose(R),mat)
        return resultat

    
    def tri_coord_ref(self, liste_slr, mat_desordre):
        """
        
        """
        vecteur_tri = np.array([[]])
        for i in range(len(liste_slr)):
            for j in range( mat_desordre.shape[0]):
                if mat_desordre[j][0] == liste_slr[i]:
                    liste_temp = np.array([[mat_desordre[j][0], mat_desordre[j][1]], 
                                           [mat_desordre[j][0],mat_desordre[j][2]], 
                                            [mat_desordre[j][0],mat_desordre[j][3]]])
                    if vecteur_tri.shape == (1,0):
                        vecteur_tri = liste_temp
                    else:
                        vecteur_tri = np.concatenate((vecteur_tri, liste_temp))
                    break
        return vecteur_tri




                
            
            
            
    
    def convert(self,date) :
        """
        Fonction permettant de convertir une date au format  en 
        parametre: date format 'YY:DD:SS'
        sortie: date format 'YY:DD:HH:M' compatible avec le module astropy
                pour apres la convertir en jour julien modifie
        """
        
        form=date.split(':')
       
        if form[0]<='50' and form[0]>='0':
            year='20'+form[0]
        else:
            year='19'+form[0]
        day=form[1]
        h=int(float(form[2])/3600)
        m=int((float(form[2])/3600-h)*60)
        if m<10:
            m='0'+str(m)
        else:
            m=str(m)
        date_f=year+':'+day+':'+str(h)+':'+m
        return(date_f)
    


if __name__ == '__main__':
    s=SLR('simulations_test/coord_ref_slr.txt','simulations_test/soln_slr.txt','simulations_test/psd_slr.txt')
#    result=s.Soln()
    #result1=s.coord_date()
#    print(result)
    #print(result1)
#    e1=s.etape1()
#    #print(e1)
#    e2=s.etape2()
    e3=s.e3
    print(e3)
#    coord_ref = s.coord_ref_slr
#    time = 57877.5
#    L=seismic(time).L(time)
    
    test_ref = s.coord_ref_slr
    test=s.coord_sans_trie
#    test_trie = s.coord_avec_trie
