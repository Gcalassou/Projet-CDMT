# -*- coding: utf-8 -*-
"""
Created on Wed Apr 19 16:13:52 2017

@author: Gabriel
"""
import epoch #### A REMPLACER
import DOMES as d
import numpy as np
import os
import options as opt

"""Ce script permet d'identifier les stations GPS co-localisées en fonction 
des préferences indiquées par l'utilisateur dans un fichier de préférences.

Entrée:
-- dossier_gps : chemin du dossier contenant les fichiers GPS
-- fichier_snx : 
-- code : 
-- liste_stations_gps : 
-- path_fichier_gps : 

Sortie:
-- station_co_loc().remplissage() : 
    matrice contenant un ensemble d'informations relatives aux stations GPS co-localisées
    chaque ligne possède les informations suivantes : 
                        [code_slr, code_GPS {associé}, jour de mesure, de, dn, dh, dsigma_x, d_sigma_n, d_sigma_h]
                        l'ensemble des valeurs de la matrice est du type "string"
"""

class station_co_loc:
    def __init__(self, dossier_gps, bloc_epoch, fichier_codomes ):
        #PARAMETRE EN ENTREE
        self.dossier_gps = dossier_gps
        self.bloc_epoch = bloc_epoch
        self.fichier_codomes = fichier_codomes
        
#        self.code = [int(n[0]) for n in bloc_epoch] ###
#        self.date_debut = [float(n[1]) for n in bloc_epoch] 
#        self.date_fin = [float(n[2]) for n in bloc_epoch]
        #liste des noms des stations GPS contenus dans le dossier
        self.liste_stations_gps = [n[:4] for n in os.listdir(self.dossier_gps)]
        
        #liste des chemins des fichiers des stations GPS contenus dans le dossier
        self.path_fichier_gps = [fichier for fichier in os.listdir(self.dossier_gps)]
#        self.d_init = 22730 #PARAMETRE TEMPORAIRE
#        self.d_fin = 55730 #PARAMETRE TEMPORAIRE
        
        #PARAMETRE EN SORTIE
        #matrice contenant les informations relatives aux stations GPS co-localisées
        self.stations_GPS_coloc = self.information_stations_GPS_coloc()
        
        
    ##### FONCTION TEMPORAIRE #####   
#    def fichier_preference(self):
#        fichier = open('rapport\\station_coloc.txt', 'w')
##        fichier.write('Liste des stations co-localisées\n\n')
#        for i in range(len(self.code)):
#            fichier.write(str(self.code[i])+'   '+str(round(self.date_debut[i],6))+'  '+str(round(self.date_fin[i],6))+'\n')
##            fichier.write(str(self.code[i]))+'   '+str(self.d_init)+'   '+str(self.d_fin))
#        fichier.close()
    ###############################
        
    def information_stations_GPS_coloc(self):
        """Fonction renvoyant les stations gps co-localisées correspondant aux stations slr
        choisie par l'utilisateur dans le fichier de préférence 

        sortie 
        -- resultat_slr_gps : matrice dont chaque ligne possède les informations suivantes
                        [code_slr, code_GPS {associé}, jour de mesure, de, dn, dh, dsigma_x, d_sigma_n, d_sigma_h]
                        l'ensemble des valeurs de la matrice est du type "string"
        """
        #matrice résultat pour l'instant vide
        resultat_slr_gps = np.array([[]])

        #lecture du fichier de préfences 
        fichier = open('rapport\\station_coloc.txt', 'r')
        
        #on stocke le contenu du fichier lu dans une variable puis on ferme le fichier
        contenu = fichier.readlines()
        fichier.close()

        #on parcourt le contenu du fichier
        for ligne in contenu:
            ligne = ligne.split()
            
            #on initialise un booléen indiquant si la station doit être supprimer
            supression_station = False
            
            
            ########## Cas où l'utilisateur n'a entré aucunes stations #########
            
            #on test si une station ou plusieurs on étaient entrées par l'utilisateur
            #si le nombre d'éléments dans la ligne est inférieur à 4, cela signifie que non
            if len(ligne) < 4:
                
                #on initialise un booléen permettant de tester l'existence d'une station
                #dans la liste de fichier GPS
                existence_station = False
                #on effectue le test
                try:
                    #on recherche les stations GPS associées à une station slr
                    #on obtient une liste en sortie
                    temp = d.DOMES('GPS', ligne[0],self.fichier_codomes)
                    temp2 = temp.conversion()
                    temp_gps = d.DOMES('Laser', temp2[:5], self.fichier_codomes)
                    liste_gps = temp_gps.conversion() # liste des stations GPS associées à la station slr testée
                    
                    #on teste si parmis les stations GPS obtenues, l'une d'entre elles 
                    #se trouve dans les stations GPS à notre disposition
                    for station in liste_gps:
                        if station in self.liste_stations_gps:   
                            ligne += [station] # on ajoute la station à la ligne du contenu
                            existence_station = True #station trouvée
                            break
                
                #station non-trouvée
                except:
                    print(ligne[0])
                    pass
                
            ########## Cas où l'utilisateur ne souhaite pas utilisé une station slr en particulier ##########
            
            elif ligne[3] =='-1':
                supression_station = True
                print('station laser n°'+str(ligne[0])+' supprimée.')
                
            ########## Cas où l'utilisateur a entré une ou plusieurs stations ##########
                
            else:
                
                existence_station = False
                
                #on parcours les stations entrées par l'utilisateur
                for i in range(3, len(ligne)):
                    
                    #on test si les stations entrées sont dans notre jeu de données
                    if ligne[i] in self.liste_stations_gps:   
                        ligne =ligne[:3]+ [ligne[i]]
                        existence_station = True #station trouvée
                        break
                    
                ###Cas où la station n'a pas été trouvée###
                # on effectue la même méthode que dans le cas où l'utilisateur 
                #n'a pas entrée de stations GPS de préférence 
                if existence_station == False:
                    
                    try:
                        
                        temp = d.DOMES('GPS', ligne[0], self.fichier_codomes)
                        temp2 = temp.conversion()
                        temp_gps = d.DOMES('Laser', temp2[:5], self.fichier_codomes)
                        liste_gps = temp_gps.conversion()
                        for station in liste_gps:
                            if station in self.liste_stations_gps:   
                                ligne += [station]
                                existence_station = True
                                break
                        print('choix de la valeur par défaut : '+str(ligne[0]))
                        
                    except:
                        print('rejet de la station slr n°'+str(ligne[0]))
                        pass
                    
            ########## Cas où une station GPS a pu être associée à une station slr ##########
                    
            if existence_station == True:
                
                #on cherche les dates de début et de fin de mesure associées à la station slr
                for i in range(self.bloc_epoch.shape[0]):
                    if ligne[0] == self.bloc_epoch[i][0]:
                        date_debut_mesure = self.bloc_epoch[i][1]
                        date_fin_mesure = self.bloc_epoch[i][2]
                        break
                
                # on fait appel à la méthode "station_coloc" pour extraire les données de déplacement
                #et des résidus associés à une station GPS

                test_contenu = self.station_coloc(ligne[0], ligne[3],date_debut_mesure,date_fin_mesure)
                
                #Cas où les dates des mesures GPS ne correspondent pas aux dates des mesures
                # des stations slr
                if test_contenu.shape == (1,0):
                    supression_station = True
                    
                #Cas où les dates des mesures GPS correspondent aux dates des mesures
                # des stations slr
                #on stocke les données dans la matrice de sortie
                if supression_station == False:
                    if resultat_slr_gps.shape == (1,0):
                        resultat_slr_gps = test_contenu
                    else:
                        resultat_slr_gps = np.concatenate((resultat_slr_gps, test_contenu), axis = 0)
#                    for  value in ligne:
#                        fichier2.write(value + ' ')
#                    fichier2.write('\n')
                
            else:
                print( ligne[0])
                
        return resultat_slr_gps
        
        
    def station_coloc(self, station_slr, station_gps, debut, fin ):
        """Fonction testant si la date d'acquisition des mesures GPS d'une station correspond 
        à la date des mesures de la station laser associée.
        
        paramètres
        -- station_slr : station slr testée
        -- station_gps : nom de la station gps associé à la station slr
        -- debut : date de debut des acquisitions de la station slr testée
        -- fin : date de fin des acquisitions de la station slr testée
        
        sortie
        -- station_interet : matrice contenant pour une seule station slr avec sa station 
                             GPS associée les déplacements et les dsigma de cette dernière
                             en coordonnées planimétriques.
                             Les lignes de la matrice possèdent les informations suivantes :
                             [code_slr, code_GPS {associé},fraction de jour, jour de mesure,
                             de, dn, dh, dsigma_x, d_sigma_n, d_sigma_h]
        """
        path = self.dossier_gps
        
        #variable dans laquelle seront stockés les mesures dont les dates correspondent
        #aux dates des mesures des stations slr 
        station_interet = np.array([[]])
        
        #on récupère le chemin de la station GPS testée
        for fichier in self.path_fichier_gps:
            if station_gps == fichier[:4]:
                path += "\\" +fichier
                break
        
        
        #on extrait les données du fichier GPS
        mat = np.genfromtxt(path)
        
        #on parcours le contenu des données du fichier
        for i in range(mat.shape[0]):
            
            #on test si la date de mesure se trouve dans la période de mesure slr
            if int(mat[i][0])>= int(float(debut)) and int(mat[i][0]) < int(float(fin))+1:
                
                # on extrait les pourcentages de journée pour lesquels le GPS a mesuré
                fraction = 0
                if -int(mat[i][0])+float(debut)<1 and -int(mat[i][0])+float(debut)>0 and -int(mat[i][0]) + float(fin)<1 and -int(mat[i][0]) + float(fin)>0:
                    fraction =  (1-(-int(mat[i][0])+float(debut)))+ ( -int(mat[i][0]) + float(fin)) -1
                elif -int(mat[i][0])+float(debut)<1 and -int(mat[i][0])+float(debut)>0 :
                    fraction = 1-(-int(mat[i][0])+float(debut))
                elif -int(mat[i][0]) + float(fin)<1 and -int(mat[i][0]) + float(fin)>0:
                    fraction = -int(mat[i][0]) + float(fin)
                else:
                    fraction = 1
                
                #on stocke l'ensemble des infomations relative à une station GPS co-localisée
                gps_data = np.array([[ station_slr, station_gps, fraction,  mat[i][0],mat[i][5],mat[i][6],mat[i][7],mat[i][8],mat[i][9],mat[i][10]]])
                if station_interet.shape[1] == 0:
                    station_interet = gps_data
                else:
                    station_interet = np.concatenate((station_interet, gps_data), axis = 0)

        return station_interet
        


        
if __name__ == "__main__":
    ##### PHASE DE TEST #####
    s = station_co_loc()

#    s.fichier_preference()

    #test de l'extraction des stations co-localisées
#    test_2 = s.remplissage()
    
    #test de l'extraction des données des stations co-localisées
#    liste_gps = s.liste_stations_gps
#    s_coloc = s.station_coloc('CHAN', 57746.129, 57752.447)
    