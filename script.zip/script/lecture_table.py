# -*- coding: utf-8 -*-
"""
Created on Wed May 10 13:46:24 2017

@author: Gabriel
"""

import numpy as np 

class tableau:
    def __init__(self, path):
        self.path = path
        self.contenu = self.lecture()
        self.contenu_utile = np.delete(self.contenu, [2, 10, 11, 12, 13], 1)
        
    def lecture(self):
        fichier= open(self.path, 'r')
        lignes = fichier.readlines()
        mat_resultat = np.array([[]])
        for ligne in lignes :
            if ligne[0] =='*':
                pass
            else:
                ligne_temp = ligne.split()
                ligne_temp = np.array([ligne_temp])
                if mat_resultat.shape == (1,0):
                    mat_resultat = ligne_temp
                else:
                    mat_resultat = np.concatenate((mat_resultat, ligne_temp))
        return mat_resultat
        
if __name__ == '__main__':
    l = tableau('ITRF2014-ILRS-TRF.dat')
    test1 =  l.contenu
    test2 = l.contenu_utile