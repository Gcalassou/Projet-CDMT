# -*- coding: utf-8 -*-
"""
Created on Wed May  3 13:48:04 2017

@author: dpts
"""

from astropy.time import Time
import numpy as np
#import options as opt 

"""Ce script permet de lire les différentes parties des fichiers de type "snx" contenant 
les informations relatives aux stations laser participant au calcul de l'ITRF.

Entrée:
-- opt.fichier_slr : chemin du fichier laser entré par l'utilisateur

Sortie:
-- Laser().Epoch() : matrice contenant les informations nous intéressant du bloc "SOLUTION/EPOCHS"
-- Laser().Domes() : matrice contenant les informations nous intéressant du bloc "SITE/ID"
-- Laser().Estimate_solution() : matrice contenant les informations nous intéressant du bloc "SOLUTION/ESTIMATE"
-- Laser().Matrice_cov() : matrice contenant les informations nous intéressant du bloc "SOLUTION/MATRIX_ESTIMATE"

"""

class Laser:
    
    def __init__(self, fichier_slr):
        #chemin du fichier slr
        self.fichier_slr = fichier_slr
        
        #matrice contenant les informations du bloc epoch
        self.bloc_epoch = self.Epoch()
        
        #matrice contenant les informations du bloc site/id
        self.bloc_siteid = self.Domes()
        
        #matrice contenant les informations du bloc estimate_solution
        self.bloc_estimate_solution = self.Estimate_solution()
        
        #matrice contenant les informations du bloc estimate_matrix
        self.matrice_covariance = self.Matrice_cov()
        
    
    def Epoch(self):
        """
        Fonction permettant de lire le bloc EPOCHS d'un fichier SLR
        
        Entrée:
        -- fichier SLR : fichier snx
        
        Sortie: 
        -- mat_resultat : matrice dont chaque ligne contient : 
                          [code station,date de début d'acquisition {MJD}, 
                          date de fin d'acquisition{MJD} ,mean epoch{MJD}]
        """
        #lecture du fichier snx
        fichier=open(self.fichier_slr,'r')
        lignes=fichier.readlines()
        
        
        #matrice contenant les informations en sortie
        mat_resultat = np.array([[]])
        
        #indice de la ligne du fichier
        i=0
        
        #on parcours les lignes du fichier jusqu'à trouver le bloc 'SOLUTION/EPOCHS'
        for ligne in lignes:

            if ligne[0:16]=='+SOLUTION/EPOCHS':
                
                #indice des lignes au sein du bloc auquel on s'intérresse
                j=i+2
                
                #on parcours le contenu du bloc et on stocke les données nous intéressant 
                #dans la matrice de sortie
                while (lignes[j])[0:16]!='-SOLUTION/EPOCHS':
                    ligne_test=lignes[j] 
                    
                    #code de la station slr
                    code=ligne_test[1:5]
                    
                    #date de début des acquisitions que l'on converti au format 'MJD'
                    dat_deb=Laser.convert(ligne_test[16:28])
                    date_debut=Time(dat_deb)
                    date_debut.format='mjd'
                    
                    #date de fin des acquisitions que l'on converti au format 'MJD'
                    dat_fin=Laser.convert(ligne_test[29:41])
                    date_fin=Time(dat_fin)
                    date_fin.format='mjd'
                    
                    #date de moyenne des acquisitions que l'on converti au format 'MJD'
                    dat_mean = Laser.convert(ligne_test[42:54])
                    date_mean =Time(dat_mean)
                    date_mean.format = 'mjd'
                    
                    # Point
                    Point= ligne_test[7:8]                   
                    
                    #on stocke les informations
#                    liste_temp = np.array([[code,ligne_test[16:28],ligne_test[29:41], ligne_test[42:54]]])
                    liste_temp = np.array([[code,date_debut.value,date_fin.value, date_mean.value,Point]])
                    if mat_resultat.shape == (1,0):
                        mat_resultat = liste_temp
                    else:
                        mat_resultat = np.concatenate((mat_resultat, liste_temp))

                    j += 1
            i+=1
        fichier.close()
        return(mat_resultat)
                
    
    def Domes(self):
        """
        Fonction lisant le bloc SITE/ID d'un fichier SLR et extrayant ses informations
        
        Entrée: 
        -- fichier SLR : fichier snx
        
        Sortie: 
        -- mat_resultat : matrice contenant les codes des stations avec leurs DOMES correspondant
                          type (mat_resultat[l][c]) = {string}
        """
        
        #lecture du fichier snx
        fichier=open(self.fichier_slr,'r')
        lignes=fichier.readlines()
        
        #indice de la ligne du fichier
        i=0
        
        #matrice contenant les informations en sortie
        mat_resultat = np.array([[]])

        #on parcourt le contenu du fichier jusqu'à trouver le bloc 'SITE/ID'
        for ligne in lignes:
            if ligne[0:8]=='+SITE/ID':
                
                #indice des lignes au sein du bloc
                j=i+2
                
                #on parcours le bloc 'SITE/ID'
                while ((lignes[j]).split())[0]!='-SITE/ID':
                    ligne_test=lignes[j]
                    
                    #code des stations slr
                    code=ligne_test[1:5]
                    
                    #Domes des statoins slr
                    DOMES=ligne_test[9:18]
                    
                    
                    #on stocke ces informations
                    liste_temp=np.array([[code,DOMES]])
                    if mat_resultat.shape == (1,0):
                        mat_resultat = liste_temp
                    else:
                        mat_resultat = np.concatenate((mat_resultat, liste_temp))
                    
                    j+=1
                break
            i+=1
        fichier.close()
        return(mat_resultat)
        
    def Estimate_solution(self):
        """
        Fonction permettant de lire le bloc 'SOLUTION/ESTIMATE'
        
        Entrée: 
        -- fichier SLR : fichier snx

        Sortie: 
        -- resultat: matrice dont chaque ligne contient :
                    [code station, STAX,STAY,STAZ]
                    
        --nombre_ligne : nombre de ligne du bloc 'SOLUTION/ESTIMATE'
        """
        #lecture du fichier snx
        fichier=open(self.fichier_slr,'r')
        lignes=fichier.readlines()
        
        #indice de la ligne du fichier
        i=0
        
        #matrice contenant les informations en sortie
        resultat = np.array([[]])
        
        #on parcourt le contenu du fichier jusqu'à trouver le bloc 'SOLUTION/ESTIMATE'
        for ligne in lignes:
            if ligne[0:18] =='+SOLUTION/ESTIMATE':
                
                #indice des lignes au sein du bloc
                j=i+2
                
                #•on parcours le bloc afin de trouver les positions de la station en x, y, z
                while (lignes[j])[0:18]!='-SOLUTION/ESTIMATE':
                    if (lignes[j])[7:11]=='XPO ' or (lignes[j])[7:11]=='YPO ' or (lignes[j])[7:11]=='LOD ':
                        j=j+1
                    else:
                        
                        ligne_test=lignes[j]
                        
                        #on récupère le code de la station slr
                        code=int(ligne_test[14:18])
                        
                        #on récupère la position de la station slr en x
                        STAX=float(ligne_test[47:68])
                        
                        #on récupère la position de la station slr en y
                        STAY=float((lignes[j+1])[47:68])
                        
                        #on récupère la position de la station slr en z
                        STAZ=float((lignes[j+2])[47:68])
                        
                        #on stocke les informations
                        position_temp = np.array([[code,STAX,STAY,STAZ]])
                        if resultat.shape == (1,0):
                            resultat = position_temp
                        else:
                            resultat = np.concatenate((resultat, position_temp))
                        j+=3                
                break
            i+=1
            
        #on récupère le nombre de ligne du bloc
        nombre_ligne = j-(i+2)
        
        fichier.close()
        return resultat, nombre_ligne

    
        
    def Matrice_cov(self):
        """
        Fonction permettant de lire le bloc 'SOLUTION/MATRIX_ESTIMATE' correspondant à la matrice de covariance
        
        Entrée: 
        -- fichier SLR : fichier snx
        
        Sortie: 
        -- mat : matrice de covariance de l'ensemble des stations slr
        """
        #lecture du fichier snx
        fichier=open(self.fichier_slr,'r')
        lignes=fichier.readlines()
        
        #on récupère le nombre de lignes du bloc 'SOLUTION/ESTIMATE'
        #pour obtenir la taille de la matrice de sortie
        dim = self.bloc_estimate_solution[1]
        
        #matrice ayant pour but de stocker les valeurs de la matrice de covariance
        mat = np.zeros((dim,dim))
        
        #indice de la ligne du fichier
        i=0
        
        #on parcours le fichier jusqu'à trouver le bloc 'SOLUTION/MATRIX_ESTIMATE'
        for ligne in lignes :
            if ligne[0:25] == '+SOLUTION/MATRIX_ESTIMATE':
                
                #indice des lignes du bloc
                j=i+2
                
                #on parcours le bloc
                while (lignes[j])[0:25]!='-SOLUTION/MATRIX_ESTIMATE':

                    ligne_test=lignes[j]
                    
                    #indice de la ligne de la matrice
                    PAR1=int(ligne_test[3:6])
                    
                    #indice de la colonne de la matrice
                    PAR2=int(ligne_test[9:12])
                    #print(PAR2)
                    
                    #on stocke les valeurs de la matrice de covariance
                    PAR_temp= [ligne_test[13:34], ligne_test[35:56], ligne_test[57:78]]
                    valeur_a_supprimer = []
                    for k in range(len(PAR_temp)):
                        if PAR_temp[k] == '':
                            valeur_a_supprimer += [k]
                    PAR_temp = np.delete(PAR_temp, valeur_a_supprimer)
                    
                    for i in range(len(PAR_temp)):
                        mat[PAR1-1][PAR2+i-1]=PAR_temp[i]
             
                    j+=1
                break
            i+=1
        return mat
    
        
    
    def convert(date) :
        """
        Fonction permettant de convertir une date au format  en 
        Entrée:
        --date : date d'une mesure au format 'YY:DD:SS'
        sortie: 
        --date_f : date format 'YY:DD:HH:M' compatible avec le module astropy
                    pour apres la convertir en jour julien modifie
        """
        
        form=date.split(':')
       
        if form[0]<='50' and form[0]>='0':
            year='20'+form[0]
        else:
            year='19'+form[0]
        day=form[1]
        h=int(float(form[2])/3600)
        m=int((float(form[2])/3600-h)*60)
        if m<10:
            m='0'+str(m)
        else:
            m=str(m)
        date_f=year+':'+day+':'+str(h)+':'+m
        return(date_f)
    
if __name__ == '__main__':
    l=Laser('ilrsb.pos+eop.170507.v135.snx')
    bloc2_epoch =l.Epoch()
#    print()
    bloc2_domes = l.Domes()
    #print(bloc2_epoch)
    bloc2_estimate_solution = l.Estimate_solution()
    bloc2_matrice_cov = l.Matrice_cov()
    