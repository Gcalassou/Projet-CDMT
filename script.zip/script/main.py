# -*- coding: utf-8 -*-
"""
Created on Mon May  8 17:12:22 2017

@author: Gabriel
"""

import options as opt
import station_co_loc 
import lecture_fichier_snx
#from options import options('simulations_test\\fichier_options.txt')
import mise_en_forme 
import slr_coloc
import class_slr

import moindre_carree
"""
Classe récupérant les informations du fichier d'options.

Entrées:
-- path_fichier_option : chemin du fichier d'options

Sortie:
-- dossier_gps : chemin du dossier contenant les fichiers GPS
-- fichier_slr : chemin du fichier slr
-- fichier_ref_gps : chemin du fichier contenant les coordonnées de référence GPS
-- fichier_ref_slr : chemin du fichier contenant les coordonnées de référence SLR
-- psd_slr : chemin du fichier contenant les inforamtions sur les déformations post-seismique
-- soln_slr : chemin du fichier SOLN
-- fichier_domes : chemin du fichier codomes 
-- fichier_preference_gps : chemin du fichier de préférence GPS
-- seuil_gps : valeur du seuil pour le test des points faux GPS
-- seuil_slr : valeur du seuil pour le test des points des points slr        
"""
o = opt.options('simulations_test\\fichier_options.txt')

#print(o.dossier_gps)
#print(o.fichier_domes)
"""
Classe permettant de lire les différents blocs du fichier snx

Entrée:
-- fichier_slr {sortie classe options} : chemin du fichier slr 

Sortie:
-- bloc_epoch : matrice contenant les informations du bloc epoch
-- bloc_siteid : matrice contenant les informations du bloc site/id
-- bloc_estimate_solution : matrice contenant les informations du bloc estimate_solution
-- matrice_covariance : matrice contenant les informations du bloc estimate_matrix

"""
lfs = lecture_fichier_snx.Laser(o.fichier_slr)

"""
Classe permettant d'extraire les stations GPS co-localisées

Entrée:
-- dossier_gps {sortie classe options} : chemin du dossier contenant les fichiers GPS
-- bloc_epoch {sortie classe lecture fichier snx} : matrice contenant les informations du bloc epoch
-- fichier_domes {sortie classe options} : chemin du fichier codomes

Sortie:
-- stations_GPS_coloc : matrice contenant les informations relatives aux stations GPS co-localisées
"""
slc = station_co_loc.station_co_loc(o.dossier_gps, lfs.bloc_epoch, o.fichier_domes)

#test_station_co_loc = slc.stations_GPS_coloc
"""
Classe permettant de renvoyer les vecteurs déplacements et la matrice de covariance des stations
GPS co-localisées.

Entrée:
-- stations_GPS_coloc {classe stations_co_loc}: matrice contenant les informations 
   relatives aux stations GPS co-localisées
-- fichier_ref_gps {classe option} : chemin du fichier contenant les coordonnées de référence GPS

Sortie:
-- coord_ref_gps[1] : liste des stations slr utilisées
-- mat_xyz : vecteur des déplacements des stations GPS co-localisées
-- mat_cov : matrice des covariances des stations GPS co-localisées
"""
org  = mise_en_forme.organisation_data_gps(slc.stations_GPS_coloc, o.fichier_ref_gps)


moyenne_coord = org.moyenne_coord
moyenne_sigma = org.moyenne_cov
mat_test = org.matrice_coord_ref_gps
code_slr2 = org.code_slr_retenu
R = org.rotation
testtest= org.covariance_cartesienne
vecteur_deplacement = org.vecteur_deplacement
mat_cov =org.matrice_covariance_gps

"""
Classe permettant de créer le vecteur des positions des stations slr et la matrice de covariance
des stations slr co-localisées

Entrée:
-- fichier_slr {sortie classe options} : chemin du fichier slr 
-- coord_ref_gps[1] {sortie classe station_co_loc} : liste des stations slr utilisées
-- bloc_estimate_solution {sortie classe lecture fichier snx} : matrice contenant 
                                        les informations du bloc estimate_solution
-- matrice_covariance {sortie classe lecture fichier snx} : matrice contenant les informations du bloc estimate_matrix
                                       
Sortie:
-- vecteur_pos_slr : vecteur des positions des stations slr co-localisées 
-- matrice_cov_slr : matrice de covariance des stations slr co-localisées                                       
"""
slrc = slr_coloc.slr_coloc(o.fichier_slr, org.code_slr_retenu, lfs.bloc_estimate_solution, lfs.matrice_covariance)

vecteur_pos_slr = slrc.vecteur_pos_slr
mat_cov_slr = slrc.matrice_cov_slr
#test_vecteur_position_slr = slrc.vecteur_pos_slr
#test_matrice_cov_slr = slrc.matrice_cov_slr

cs = class_slr.SLR(o.fichier_ref_slr,o.soln_slr, o.psd_slr, org.code_slr_retenu, lfs.bloc_epoch)
test = cs.coord_ref_slr
test_cref = cs.e3
test_coord_ref = cs.coord_sans_trie
test_trie_ref = cs.coord_avec_trie

liste = cs.liste_stations_slr

mc = moindre_carree.calcul_MC(org.vecteur_deplacement, cs.coord_avec_trie, slrc.vecteur_pos_slr, org.matrice_covariance_gps, slrc.matrice_cov_slr, o.seuil_slr)
aaaa= mc.vecteur_coord_ref_slr
bbbb=mc.vecteur_deplacement_gps
cccc=mc.vecteur_pos_slr
testA = mc.matriceA
#test_vecteur_deplacement = org.vecteur_deplacement
#org = mef.organisation_data_gps()
#org.mat_cov()
#org.mat_xyz()
