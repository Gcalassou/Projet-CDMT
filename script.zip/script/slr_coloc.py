# -*- coding: utf-8 -*-
"""
Created on Thu May  4 20:30:31 2017

@author: Gabriel
"""
import numpy as np
#import options as opt





"""
Le but de ce script est d'identifier les stations slr co-localisées à partir
des stations GPS co-localisées et d'en extraire les données utiles pour le calcul 
des moindres carrées.

Entrée:
--code_slr : liste des codes des stations slr correspondant aux stations GPS 
            co-localisées extraitent précédement.
            
--bloc_estimate_solution : matrice contenant l'ensemble des données de position
                          des stations laser
                          
--bloc_matrice_cov : matrice contenant la matrice de covariance de l'ensemble des
                    stations slr
            
Sortie : 
--position_et_covariance()[0] : vecteur des positions des stations slr co-localisées.
                format : [[STAX_1], 
                          [STAY_1], 
                          [STAZ_1],
                          ...
                          [STAX_n], 
                          [STAY_n], 
                          [STAZ_n]]

-- position_et_covariance()[1] : matrice des covariances des stations slr co-localisées
"""

class slr_coloc():
    def __init__(self, fichier_slr, code_slr, bloc_estimate_solution, bloc_matrice_cov):
        #chemin du fichier slr à lire
        self.fichier_slr = fichier_slr
        
        # liste des stations co-localisées 
        self.code_slr = code_slr #org.coord_ref_gps()[1] #ATTENTION PENSER A CHANGER LA VALEUR
        
        
        self.bloc_estimate_solution = bloc_estimate_solution[0]#fichier_snx.Estimate_solution()[0]
        
        self.bloc_matrice_cov = bloc_matrice_cov#fichier_snx.Matrice_cov()
        
        self.phase_calcul_pos_cov = self.position_et_covariance()
        
        self.vecteur_pos_slr = self.phase_calcul_pos_cov[0]
        
        self.matrice_cov_slr = self.phase_calcul_pos_cov[1]
        
    def position_et_covariance(self):
        """Fonction permettant de créer le vecteur des positions et la matrice de covariance 
        des stations slr co-localisées
        
        Entrées:
        -- bes : matrice contenant les positions en x, y, z des stations slr
        -- code : liste des stations co-localisées
        -- mat : matrice de variance-covariance de l'ensemble des stations slr
        
        Sortie:
        -- vecteur_position : vecteur des positions des stations slr co-localisées
        -- matrice_covariance : matrice de variance covariance des stations slr co-localisées
        
        """
        
        ########## Calcul du vecteur des positions ##########
        
        #matrice contenant les positions en x, y, z des stations slr
        bes = self.bloc_estimate_solution 
        
        #liste des stations co-localisées
        code = self.code_slr
        
        #liste des indices des lignes et colonnes à garder pour la matrice
        #de variance covariance
        indice = []
        
        vecteur_position = np.array([[]])
        
        for i in range(code.shape[0]):
            for j in range(bes.shape[0]):
                #on identifie les stations slr co-localisées
                if bes[j][0] == code[i]:
                    #on extrait les indices 
                    indice +=[3*j, 3*j+1, 3*j+2]
                    #on stocke les positions
                    vecteur_temp = np.array([[bes[j][0]],
                                             [bes[j][1]],
                                             [bes[j][2]]])
                    if vecteur_position.shape == (1,0):
                        vecteur_position = vecteur_temp
                    else:
                        #on rajoute les positions extraites au vecteur des positions
                        vecteur_position = np.concatenate((vecteur_position, vecteur_temp))
                        
        ########## Calcul de la matrice de covariance des stations slr ##########              
                        
        #extraction de la matrice de covariance de l'ensemble des stations slr
        mat = self.bloc_matrice_cov
        
        #liste des indices des lignes et colonnes à supprimer de la matrice
        ligne_a_supprimer = [n for n in range(mat.shape[0])]
        ligne_a_supprimer = np.delete(ligne_a_supprimer, indice)
        
        #suppression des lignes et des indices indésirables 
        #création de la matrice de covariance des stations co-localisées
        matrice_covariance = np.delete(mat, ligne_a_supprimer, 0)
        matrice_covariance = np.delete(matrice_covariance, ligne_a_supprimer, 1)
        
        return vecteur_position, matrice_covariance
    
        
if __name__ == '__main__':
    ##### PHASE DE TEST #####
    s = slr_coloc()

    #test de la fonction de création du vecteur position et de la matrice de variance covariance
    # des stations slr co-localisées
    slr_position = s.position_et_covariance()[0]
    slr_covariance = s.position_et_covariance()[1]

        